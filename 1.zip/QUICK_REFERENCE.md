# ⚡ BuildWise - Quick Reference Card

## 🚀 Installation (30 seconds)
```bash
pip install -r requirements.txt
python app.py
# Open: http://localhost:5000
```

## 📋 Construction Rates (Indian Market)
| Type | Rate/sqft | Best For |
|------|-----------|----------|
| Basic | ₹1,600-1,900 | Budget homes |
| Standard | ₹2,000-2,500 | Most homes (Recommended) |
| Premium | ₹2,600-3,500 | Luxury homes |

## 🏗️ Timeline Estimates
| Floors | Duration | Notes |
|--------|----------|-------|
| G | 5-6 months | Single story |
| G+1 | 8-9 months | Two stories |
| G+2 | 11-12 months | Three stories |

## 📊 Cost Breakdown (Standard)
- Foundation: 15%
- Structure: 25%
- Brickwork: 12%
- Plastering: 10%
- Electrical: 8%
- Plumbing: 8%
- Finishing: 22%

## 🧱 Material Ratios (per sqft)
| Material | Quantity |
|----------|----------|
| Cement | 0.45 bags |
| Steel | 3.5 kg |
| Sand | 1.8 cu.ft |
| Aggregate | 1.35 cu.ft |
| Bricks | 12 nos |
| Tiles | 0.7 sqft |
| Paint | 0.15 liters |

## 👷 Labor Ratios
| Role | Ratio |
|------|-------|
| Masons | 1 per 500 sqft |
| Helpers | 1 per 250 sqft |
| Carpenters | 1 per 1500 sqft |
| Electricians | 1 per 1500 sqft |
| Plumbers | 1 per 1500 sqft |
| Man-days | 0.6 per sqft |

## 🎯 Risk Levels
| Level | Meaning | Action |
|-------|---------|--------|
| 🟢 Low | All good | Proceed |
| 🟡 Medium | Minor concerns | Review budget |
| 🔴 High | Major issues | Revise plan |

## 🏠 Vastu Layout
```
┌─────────────┬─────────────┐
│             │             │
│  Guest/Bath │ Living Hall │
│  (NW)       │    (NE)     │
│             │             │
├─────────────┼─────────────┤
│             │             │
│  Bedroom    │   Kitchen   │
│  (SW)       │    (SE)     │
│             │             │
└─────────────┴─────────────┘
```

## 🎨 3D Model Controls
- **Rotate**: Click + Drag
- **Zoom**: Scroll Wheel
- **Pan**: Right-click + Drag
- **Color**: Use color picker
- **Roof**: Click Flat/Sloped buttons

## 💬 Chat Commands (Examples)
- "How to reduce cost?"
- "Is my budget enough?"
- "Timeline realistic?"
- "Vastu compliant?"
- "Material alternatives?"

## 📁 Key Files
| File | Purpose |
|------|---------|
| app.py | Backend server |
| templates/index.html | Frontend UI |
| static/js/main.js | Core logic |
| static/js/renderer.js | 3D model |
| static/js/blueprint.js | 2D plan |
| requirements.txt | Dependencies |

## 🔧 API Endpoints
| Endpoint | Method | Purpose |
|----------|--------|---------|
| / | GET | Main page |
| /api/calculate | POST | Cost estimation |
| /api/chat | POST | AI responses |

## 📱 Navigation
| View | Shortcut | Content |
|------|----------|---------|
| Home | Click "Home" | Landing + Form |
| Dashboard | Click "Dashboard" | Cost analysis |
| Blueprint | Click "Blueprint" | 2D floor plan |
| 3D Model | Click "3D Model" | 3D visualization |
| Schedule | Click "Schedule" | Timeline |

## ⚠️ Common Issues
| Problem | Solution |
|---------|----------|
| Blank dashboard | Generate estimate first |
| 3D not loading | Check internet |
| Chat not working | Wait, fallback works |
| Wrong calculations | Verify inputs |

## 💡 Pro Tips
✅ Add 10-15% contingency to budget
✅ Use Standard quality for best value
✅ Allow extra time for approvals
✅ Buy materials in bulk
✅ Verify contractor quotes
✅ Download blueprint for reference
✅ Share 3D model with family

## 📞 Help Resources
1. **START_HERE.md** - Quick setup
2. **USER_GUIDE.md** - Detailed guide
3. **README.md** - Overview
4. **FEATURES_CHECKLIST.md** - All features
5. **test_app.py** - Test calculations

## 🎓 Sample Project
```
Area: 1200 sqft
Floors: G+1
Type: Standard
Budget: ₹50,00,000
Timeline: 9 months
City: Hyderabad

Result:
Cost: ₹54,00,000
Risk: Medium
Materials: 1080 cement bags, 8400kg steel
Labor: 4 masons, 9 helpers
Duration: 9 months (4 phases)
```

## 🏆 Best Practices
1. ✅ Accurate measurements
2. ✅ Realistic budget
3. ✅ Adequate timeline
4. ✅ Quality materials
5. ✅ Experienced contractors
6. ✅ Regular monitoring
7. ✅ Proper documentation

---

**Print this card for quick reference! 📄**
