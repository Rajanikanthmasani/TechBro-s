# BuildWise - AI Construction Planner 🏠🏗️

Welcome to **BuildWise**, your intelligent partner for planning residential construction projects in India. This application combines AI-driven cost estimation, Indian construction standards, and interactive 3D/2D visualization to help you visualize your dream home.

## 🚀 Features

- **Smart Estimation**: Calculates construction cost based on Indian market rates (Basic ₹1600/sqft, Standard ₹2200/sqft, Premium ₹3000/sqft).
- **Material & Labor Breakdown**: Detailed quantities for Cement, Steel, Bricks, Sand, Aggregate, and required labor days.
- **Interactive 3D Model**: Visualize your home in 3D with orbit controls, change wall colors and roof types.
- **2D Blueprint Generator**: Auto-generates a Vastu-compliant floor plan with downloadable PNG export.
- **AI Site Engineer**: Chat with our AI assistant for cost-saving tips and construction advice (Indian context).
- **Phase-wise Schedule**: Construction timeline broken down by phases (Foundation, Superstructure, MEP, Finishing).
- **Risk Analysis**: Budget and timeline feasibility assessment with warnings.

## 🛠️ Installation & Setup

1.  **Prerequisites**:
    - Python 3.8 or higher installed
    - An active internet connection (for loading Chart.js and Three.js libraries)

2.  **Install Dependencies**:
    Open your terminal/command prompt in this folder and run:
    ```bash
    pip install -r requirements.txt
    ```

3.  **Run the Application**:
    ```bash
    python app.py
    ```

4.  **Access the App**:
    Open your web browser and go to: `http://localhost:5000`

## 📖 How to Use

1.  **Input Details on Home Page**:
    - Enter your built-up area (e.g., 1200 sq ft)
    - Select number of floors (G, G+1, or G+2)
    - Choose construction quality (Basic/Standard/Premium)
    - Enter your budget and desired timeline
    - Select your city
    - Click **"Generate Comprehensive Plan"**

2.  **Explore the Dashboard**:
    - **Dashboard**: View total cost estimate, risk analysis (budget/timeline warnings), cost breakdown chart, material requirements table, and labor planning
    - **Blueprint (2D)**: See the generated Vastu-compliant floor plan. Click "Download PNG" to save it
    - **3D Model**: Interact with the 3D view using mouse controls (rotate, zoom). Change wall colors using the color picker or switch between flat and sloped roof
    - **Schedule**: Check the phase-wise construction timeline with duration estimates

3.  **Chat with AI Engineer**:
    - Use the chat widget (bottom right corner) to ask questions like:
        - "How can I reduce the cost?"
        - "Is this budget enough for a G+1 house?"
        - "What about timeline delays?"
    - The AI provides context-aware responses based on your project details

## 🤖 AI Configuration

The app is configured to connect to a local Ollama instance (IBM Granite 3.3 model). If Ollama is not running, it gracefully falls back to a built-in rule-based "Indian Site Engineer" system, so the chat will always work!

To use the full AI capabilities:
1. Install Ollama from https://ollama.ai
2. Pull the granite model: `ollama pull granite3.3`
3. Ensure Ollama is running on `http://localhost:11434`

## 📁 Project Structure

```
BuildWise/
├── app.py                 # Flask backend with estimation logic
├── requirements.txt       # Python dependencies
├── README.md             # This file
├── templates/
│   └── index.html        # Main HTML template
├── static/
│   ├── css/
│   │   └── style.css     # All styling
│   ├── js/
│   │   ├── main.js       # Core functionality & dashboard
│   │   ├── blueprint.js  # 2D floor plan generator
│   │   └── renderer.js   # 3D model with Three.js
│   └── images/           # (Empty - for future assets)
```

## 🎨 Features in Detail

### Cost Estimation
- Based on real Indian construction rates
- Includes 7 major cost categories: Foundation, Structure, Brickwork, Plastering, Electrical, Plumbing, Finishing
- Material quantities calculated using industry-standard ratios

### 3D Visualization
- Built with Three.js
- Interactive orbit controls
- Customizable wall colors and roof types
- Realistic lighting and shadows

### Vastu Compliance
- Floor plans follow Vastu principles
- North-East: Living/Prayer area
- South-East: Kitchen
- South-West: Master Bedroom
- North-West: Guest/Bathroom

---
*Built with ❤️ for Indian Home Builders.*

