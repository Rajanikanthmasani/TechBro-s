# 🏗️ Worker Schedule Details - BuildWise

## Overview
The worker schedule feature provides comprehensive, phase-wise breakdown of labor requirements with detailed cost calculations and timelines.

---

## 📊 Workforce Summary

The dashboard displays a high-level summary showing:
- **Total Man-Days**: Overall labor effort required
- **Masons**: Number of skilled masons needed
- **Helpers**: Supporting labor count
- **Carpenters**: Woodwork specialists
- **Electricians**: Electrical work specialists
- **Plumbers**: Plumbing specialists
- **Supervisors**: Site supervision team

---

## 🔄 Phase-Wise Breakdown

### Phase 1: Foundation & Plinth (20% of timeline)
**Duration**: Calculated based on total project timeline

**Workers Required**:
- Site Supervisor (1) - ₹1,500/day
- Masons (2-4) - ₹800/day
- Helpers (4-8) - ₹500/day
- Excavator Operator (1) - ₹1,200/day (5 days)
- Bar Benders (2) - ₹700/day

**Key Activities**:
- Site clearing
- Excavation
- Foundation laying
- Plinth beam work
- Backfilling

---

### Phase 2: Superstructure (40% of timeline)
**Duration**: Largest phase - main construction

**Workers Required**:
- Site Supervisor (1) - ₹1,500/day
- Masons (3-5) - ₹800/day
- Helpers (6-10) - ₹500/day
- Bar Benders (2) - ₹700/day
- Carpenters (2-3) - ₹750/day
- Welders (1) - ₹900/day (15 days)

**Key Activities**:
- Column casting
- Beam work
- Slab casting
- Wall construction
- Roof structure

---

### Phase 3: MEP Works (20% of timeline)
**Duration**: Mechanical, Electrical, Plumbing installations

**Workers Required**:
- Site Supervisor (1) - ₹1,500/day
- Electricians (2-3) - ₹850/day
- Plumbers (2-3) - ₹800/day
- Helpers (2) - ₹500/day
- HVAC Technician (1) - ₹1,000/day (10 days)

**Key Activities**:
- Electrical wiring
- Plumbing installation
- Drainage system
- Water tank setup
- AC provisions

---

### Phase 4: Finishing Works (20% of timeline)
**Duration**: Final touches and quality work

**Workers Required**:
- Site Supervisor (1) - ₹1,500/day
- Painters (3) - ₹650/day
- Tile Masons (2) - ₹850/day
- Carpenters (2-3) - ₹750/day
- Helpers (4-8) - ₹500/day
- Marble/Granite Workers (2) - ₹900/day (12 days)
- Grill/Window Fitters (2) - ₹800/day (8 days)

**Key Activities**:
- Plastering
- Flooring
- Tiling
- Painting
- Door/window fitting
- Kitchen setup
- Final touches

---

## 💰 Cost Calculation

Each phase shows:
1. **Worker Role**: Specific job function
2. **Count**: Number of workers needed
3. **Daily Rate**: Per-day cost per worker
4. **Total Days**: Days required for that role
5. **Total Cost**: Calculated as (Count × Daily Rate × Total Days)

**Phase Total**: Sum of all worker costs in that phase

---

## 📅 Timeline View

The Schedule section displays:
- **Total Project Duration**: In months
- **Phase-wise Timeline**: Week-by-week breakdown
- **Progress Indicators**: Visual percentage bars
- **Cumulative Timeline**: Running week count
- **Completion Marker**: Final handover milestone

---

## 🎯 Key Features

### 1. Detailed Worker Information
- Specific roles for each construction phase
- Accurate daily rates based on Indian market standards
- Realistic worker counts based on project size

### 2. Cost Transparency
- Individual worker cost breakdown
- Phase-wise total labor costs
- No hidden charges

### 3. Timeline Clarity
- Week-by-week schedule
- Phase duration in weeks and days
- Clear activity lists for each phase

### 4. Visual Design
- Color-coded phases
- Interactive hover effects
- Progress bars for timeline visualization
- Responsive tables for worker details

### 5. Professional Presentation
- Clean, modern UI
- Easy-to-read tables
- Gradient backgrounds for emphasis
- Icon-based visual cues

---

## 📱 How to View

1. **Fill the registration form** on the home page
2. **Submit** to generate estimate
3. **Navigate to Dashboard** to see:
   - Workforce Summary (top card)
   - Phase-wise worker breakdown (detailed cards)
4. **Navigate to Schedule** to see:
   - Visual timeline with progress bars
   - Week-by-week breakdown
   - Completion milestones

---

## 🔍 Understanding the Data

### Worker Counts Scale With Project Size
- Larger projects (more sq ft) = more workers
- Multi-floor buildings = extended timelines
- Premium construction = specialized workers

### Daily Rates (Indian Market - 2026)
- **Unskilled Labor**: ₹500-600/day
- **Semi-skilled**: ₹650-800/day
- **Skilled Workers**: ₹800-1,000/day
- **Specialists**: ₹1,000-1,500/day
- **Supervisors**: ₹1,500-2,000/day

### Timeline Estimates
- **Ground Floor (G)**: 6 months
- **G+1 (Two Floors)**: 9 months
- **G+2 (Three Floors)**: 12 months

---

## ✨ Benefits

1. **Budget Planning**: Know exact labor costs upfront
2. **Resource Management**: Understand worker requirements
3. **Timeline Tracking**: Phase-wise progress monitoring
4. **Cost Control**: Transparent pricing prevents overruns
5. **Quality Assurance**: Right workers for each phase

---

## 🎨 Visual Highlights

- **Purple Gradient**: Workforce summary card
- **Blue Gradient**: Phase headers
- **Yellow Highlight**: Phase total costs
- **Green Gradient**: Project completion marker
- **White Cards**: Clean, professional worker tables

---

## 📞 Support

For questions about worker schedules or labor planning:
- Use the **AI Chat Widget** on the website
- Ask about specific phases or worker roles
- Get cost-saving recommendations
- Understand timeline optimization

---

**BuildWise** - Making construction planning transparent and professional! 🏗️✨
