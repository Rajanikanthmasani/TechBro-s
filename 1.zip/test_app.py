"""
Simple test script to verify BuildWise functionality
"""
import json

# Test the ProjectManager calculation logic
from app import ProjectManager

def test_basic_calculation():
    """Test basic cost estimation"""
    test_data = {
        'area': 1200,
        'floors': 'G+1',
        'construction_type': 'Standard',
        'budget': 5000000,
        'timeline': 9
    }
    
    result = ProjectManager.calculate_estimate(test_data)
    
    print("=" * 60)
    print("BuildWise - Test Results")
    print("=" * 60)
    print(f"\nInput Data:")
    print(f"  Area: {test_data['area']} sq ft")
    print(f"  Floors: {test_data['floors']}")
    print(f"  Type: {test_data['construction_type']}")
    print(f"  Budget: ₹{test_data['budget']:,}")
    print(f"  Timeline: {test_data['timeline']} months")
    
    print(f"\n✓ Total Cost Estimate: ₹{result['total_cost']:,.0f}")
    print(f"✓ Per Floor Cost: ₹{result['per_floor_cost']:,.0f}")
    print(f"✓ Risk Level: {result['risk']['level']}")
    print(f"✓ Estimated Timeline: {result['schedule']['Months']} months")
    
    print(f"\nCost Breakdown:")
    for category, amount in result['breakdown'].items():
        print(f"  {category}: ₹{amount:,}")
    
    print(f"\nKey Materials:")
    for material, qty in list(result['materials'].items())[:5]:
        print(f"  {material}: {qty}")
    
    print(f"\nLabor Requirements:")
    for role, count in result['labor'].items():
        if role != 'TotalManDays':
            print(f"  {role}: {count}")
    
    print("\n" + "=" * 60)
    print("✓ All calculations completed successfully!")
    print("=" * 60)

if __name__ == '__main__':
    test_basic_calculation()
