// State
let projectContext = {};
let costChart = null;

// Handle Form Submission
document.getElementById('project-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    // UI Helpers
    const btn = document.querySelector('button[type="submit"]');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    btn.disabled = true;

    // Collect Data with user registration info
    const formData = {
        // User Information
        name: document.getElementById('user-name').value,
        phone: document.getElementById('user-phone').value,
        email: document.getElementById('user-email').value || '',
        
        // Project Details
        area: document.getElementById('area').value,
        floors: document.getElementById('floors').value,
        construction_type: document.getElementById('construction_type').value,
        budget: document.getElementById('budget').value,
        timeline: document.getElementById('timeline').value,
        city: document.getElementById('city').value,
        start_time: document.getElementById('start-time').value,
        requirements: document.getElementById('requirements').value || '',
        vastu: document.getElementById('vastu') ? document.getElementById('vastu').checked : false
    };
    
    // Validation
    if (!formData.name || formData.name.trim() === '') {
        alert('Please enter your name');
        btn.innerHTML = originalText;
        btn.disabled = false;
        return;
    }
    
    if (!formData.phone || !/^[0-9]{10}$/.test(formData.phone)) {
        alert('Please enter a valid 10-digit mobile number');
        btn.innerHTML = originalText;
        btn.disabled = false;
        return;
    }
    
    if (!formData.area || formData.area <= 0) {
        alert('Please enter a valid area (greater than 0)');
        btn.innerHTML = originalText;
        btn.disabled = false;
        return;
    }

    try {
        const response = await fetch('/api/calculate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        if (!response.ok) throw new Error('Network response was not ok');

        const data = await response.json();
        projectContext = { ...formData, ...data };

        // Populate Dashboard
        populateDashboard(data);

        // Initialize Blueprint
        if (typeof initBlueprint === 'function') {
            initBlueprint(formData, data.breakdown);
        }

        // Initialize 3D Model
        if (typeof init3DModel === 'function') {
            init3DModel(formData);
        }

        // Switch to Dashboard
        switchView('dashboard');

        // Success message
        alert(`✓ Estimate Generated!\n\nTotal Cost: ₹${data.total_cost.toLocaleString()}\nTimeline: ${data.schedule.Months} months\n\nThank you, ${formData.name}! We'll contact you at ${formData.phone}`);

    } catch (error) {
        console.error('Error:', error);
        alert('Error generating estimate. Please try again.');
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
});

function populateDashboard(data) {
    // Display Total Cost
    const totalCostEl = document.getElementById('disp-total-cost');
    if (totalCostEl) {
        totalCostEl.textContent = `₹${data.total_cost.toLocaleString()}`;
    }

    // Display Risk
    const riskLevelEl = document.getElementById('disp-risk-level');
    const riskMsgEl = document.getElementById('disp-risk-msg');
    if (riskLevelEl && data.risk) {
        riskLevelEl.textContent = data.risk.level;
        riskLevelEl.style.color = data.risk.level === 'High' ? '#ef4444' : (data.risk.level === 'Medium' ? '#f59e0b' : '#10b981');
    }
    if (riskMsgEl && data.risk) {
        riskMsgEl.textContent = data.risk.warnings.join('. ') || 'No major risks identified';
    }

    // Display Timeline
    const monthsEl = document.getElementById('disp-months');
    if (monthsEl && data.schedule) {
        monthsEl.textContent = `${data.schedule.Months} Months`;
    }

    // Cost Breakdown Chart
    const ctx = document.getElementById('costChart');
    if (ctx) {
        if (costChart) costChart.destroy();
        
        const labels = Object.keys(data.breakdown);
        const values = Object.values(data.breakdown);
        
        costChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: values,
                    backgroundColor: ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
    }

    // Material List
    const matList = document.getElementById('material-list');
    if (matList) {
        matList.innerHTML = '';
        for (const [key, val] of Object.entries(data.materials)) {
            matList.innerHTML += `<tr><td>${key}</td><td>${val}</td></tr>`;
        }
    }

    // Labor List
    const laborDiv = document.getElementById('labor-details');
    if (laborDiv && data.labor) {
        laborDiv.innerHTML = '';
        
        // Check if labor has summary or is in old format
        const laborData = data.labor.summary || data.labor;
        
        for (const [key, val] of Object.entries(laborData)) {
            if (key !== 'TotalManDays' && key !== 'phases') {
                laborDiv.innerHTML += `<div class="labor-item"><h4>${val}</h4><small>${key}</small></div>`;
            }
        }
    }

    // Schedule - Enhanced with detailed week-by-week labor planning
    const timelineDiv = document.getElementById('timeline-list');
    if (timelineDiv && data.schedule) {
        timelineDiv.innerHTML = '';
        
        // Add header with total duration
        const headerDiv = document.createElement('div');
        headerDiv.className = 'schedule-header';
        headerDiv.innerHTML = `
            <div class="schedule-title">
                <h2><i class="fas fa-calendar-alt"></i> Construction Timeline & Labor Planning</h2>
                <p>Detailed week-by-week breakdown with worker requirements</p>
            </div>
            <div class="schedule-duration">
                <div class="duration-box">
                    <span class="duration-number">${data.schedule.Months}</span>
                    <span class="duration-label">Total Months</span>
                </div>
            </div>
        `;
        timelineDiv.appendChild(headerDiv);
        
        // Add phases with detailed weekly breakdown
        let weekCounter = 0;
        data.schedule.Phases.forEach((phase, index) => {
            const startWeek = weekCounter + 1;
            const phaseWeeks = Math.round(phase.duration_weeks);
            weekCounter += phaseWeeks;
            const endWeek = weekCounter;
            
            // Get labor data for this phase
            let laborInfo = '';
            let weeklyBreakdown = '';
            
            if (data.labor && data.labor.phases && data.labor.phases[index]) {
                const phaseLabor = data.labor.phases[index];
                
                // Create weekly breakdown
                weeklyBreakdown = `
                    <div class="weekly-breakdown">
                        <h4><i class="fas fa-calendar-week"></i> Week-by-Week Schedule:</h4>
                        <div class="weeks-grid">
                            ${Array.from({length: phaseWeeks}, (_, i) => {
                                const weekNum = startWeek + i;
                                const weekProgress = ((i + 1) / phaseWeeks) * 100;
                                return `
                                    <div class="week-card">
                                        <div class="week-header">
                                            <span class="week-number">Week ${weekNum}</span>
                                            <span class="week-progress">${Math.round(weekProgress)}%</span>
                                        </div>
                                        <div class="week-workers">
                                            ${phaseLabor.workers.slice(0, 3).map(w => `
                                                <div class="week-worker">
                                                    <i class="fas fa-user"></i>
                                                    <span>${w.count} ${w.role}</span>
                                                </div>
                                            `).join('')}
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                `;
                
                // Labor summary for phase
                laborInfo = `
                    <div class="phase-labor">
                        <h4><i class="fas fa-users"></i> Workers Required:</h4>
                        <div class="labor-grid-mini">
                            ${phaseLabor.workers.map(worker => `
                                <div class="labor-mini-item">
                                    <span class="worker-count">${worker.count}</span>
                                    <span class="worker-role">${worker.role}</span>
                                    <span class="worker-days">${worker.total_days} days</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `;
            }
            
            const phaseDiv = document.createElement('div');
            phaseDiv.className = 'timeline-phase';
            phaseDiv.innerHTML = `
                <div class="phase-marker">
                    <div class="marker-number">${index + 1}</div>
                    <div class="marker-line"></div>
                </div>
                <div class="phase-content">
                    <div class="phase-title">${phase.name}</div>
                    <div class="phase-details">
                        <div class="detail-item">
                            <i class="fas fa-clock"></i>
                            <span>${phaseWeeks} weeks (${Math.round(phaseWeeks * 7)} days)</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-calendar-week"></i>
                            <span>Week ${startWeek} - ${endWeek}</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-calendar-alt"></i>
                            <span>Month ${Math.ceil(startWeek/4)} - ${Math.ceil(endWeek/4)}</span>
                        </div>
                    </div>
                    <div class="phase-progress">
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width: ${(phase.duration_weeks / (data.schedule.Months * 4)) * 100}%"></div>
                        </div>
                        <span class="progress-percentage">${Math.round((phase.duration_weeks / (data.schedule.Months * 4)) * 100)}% of total time</span>
                    </div>
                    ${laborInfo}
                    ${weeklyBreakdown}
                </div>
            `;
            timelineDiv.appendChild(phaseDiv);
        });
        
        // Add labor summary card
        if (data.labor && data.labor.summary) {
            const laborSummaryDiv = document.createElement('div');
            laborSummaryDiv.className = 'labor-summary-card';
            laborSummaryDiv.innerHTML = `
                <h3><i class="fas fa-hard-hat"></i> Total Workforce Summary</h3>
                <div class="labor-summary-grid">
                    ${Object.entries(data.labor.summary).map(([role, count]) => {
                        if (role === 'TotalManDays') {
                            return `
                                <div class="summary-stat highlight">
                                    <div class="stat-number">${count}</div>
                                    <div class="stat-label">Total Man-Days</div>
                                </div>
                            `;
                        }
                        return `
                            <div class="summary-stat">
                                <div class="stat-number">${count}</div>
                                <div class="stat-label">${role}</div>
                            </div>
                        `;
                    }).join('')}
                </div>
            `;
            timelineDiv.appendChild(laborSummaryDiv);
        }
        
        // Add completion marker
        const completionDiv = document.createElement('div');
        completionDiv.className = 'timeline-completion';
        completionDiv.innerHTML = `
            <div class="completion-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="completion-content">
                <h3>Project Completion</h3>
                <p>Final inspection, handover, and documentation</p>
            </div>
        `;
        timelineDiv.appendChild(completionDiv);
    }
}

// Navigation Logic
function switchView(viewId) {
    // If navigating to data-dependent views without data, warn user
    if (['dashboard', 'blueprint', '3dmodel', 'schedule'].includes(viewId) && Object.keys(projectContext).length === 0) {
        alert("Please generate an estimate first on the Home page!");
        switchView('landing');
        return;
    }

    // Hide all views
    document.querySelectorAll('.view-section').forEach(v => v.classList.add('hidden'));
    
    // Show selected view
    const targetView = document.getElementById(`view-${viewId}`);
    if (targetView) {
        targetView.classList.remove('hidden');
    }

    // Update sidebar active state
    document.querySelectorAll('.nav-links li').forEach(li => li.classList.remove('active'));
    const activeLink = Array.from(document.querySelectorAll('.nav-links li')).find(li => 
        li.textContent.toLowerCase().includes(viewId === 'landing' ? 'home' : viewId)
    );
    if (activeLink) activeLink.classList.add('active');

    // Trigger view-specific actions
    if (viewId === 'blueprint' && typeof drawBlueprint === 'function') setTimeout(drawBlueprint, 100);
    if (viewId === '3dmodel' && typeof onWindowResize === 'function') setTimeout(onWindowResize, 100);
}

function scrollToForm() {
    const form = document.getElementById('estimate-form-container');
    if (form) {
        form.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// Chat Functions
async function sendChat() {
    const input = document.getElementById('chat-input');
    const chatBody = document.getElementById('chat-body');
    
    if (!input || !chatBody) return;
    
    const message = input.value.trim();
    if (!message) return;

    // Add user message
    chatBody.innerHTML += `
        <div class="msg user">
            <div class="msg-content">${message}</div>
            <i class="fas fa-user"></i>
        </div>
    `;
    input.value = '';
    chatBody.scrollTop = chatBody.scrollHeight;

    // Show typing indicator
    const typingId = 'typing-' + Date.now();
    chatBody.innerHTML += `
        <div class="msg ai" id="${typingId}">
            <i class="fas fa-robot"></i>
            <div class="msg-content"><i class="fas fa-spinner fa-spin"></i> Thinking...</div>
        </div>
    `;
    chatBody.scrollTop = chatBody.scrollHeight;

    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                message: message,
                context: projectContext 
            })
        });

        const data = await response.json();
        
        // Remove typing indicator
        document.getElementById(typingId)?.remove();

        // Add AI response
        chatBody.innerHTML += `
            <div class="msg ai">
                <i class="fas fa-robot"></i>
                <div class="msg-content">${data.response}</div>
            </div>
        `;
        chatBody.scrollTop = chatBody.scrollHeight;

    } catch (error) {
        console.error('Chat error:', error);
        document.getElementById(typingId)?.remove();
        chatBody.innerHTML += `
            <div class="msg ai">
                <i class="fas fa-robot"></i>
                <div class="msg-content">Sorry, I encountered an error. Please try again.</div>
            </div>
        `;
        chatBody.scrollTop = chatBody.scrollHeight;
    }
}

// Quick message function
window.sendQuickMessage = function(message) {
    const input = document.getElementById('chat-input');
    input.value = message;
    sendChat();
};

// Chat Toggle
window.toggleChat = function() {
    const widget = document.querySelector('.chat-widget');
    if (widget) {
        widget.classList.toggle('minimized');
        const icon = widget.querySelector('.chat-toggle i');
        if (icon) {
            icon.classList.toggle('fa-chevron-down');
            icon.classList.toggle('fa-chevron-up');
        }
    }
};

// Global scope expose for inline onclicks
window.switchView = switchView;
window.scrollToForm = scrollToForm;
window.sendChat = sendChat;

// Initial Load
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM Loaded - Initializing...');
    
    // Allow Enter key to send chat
    const chatInput = document.getElementById('chat-input');
    if (chatInput) {
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendChat();
            }
        });
    }
    
    // Ensure landing page is visible
    const landingPage = document.getElementById('view-landing');
    if (landingPage) {
        landingPage.classList.remove('hidden');
        landingPage.style.display = 'block';
    }
    
    // Hide other views
    ['dashboard', 'blueprint', '3dmodel', 'schedule'].forEach(viewId => {
        const view = document.getElementById(`view-${viewId}`);
        if (view) {
            view.classList.add('hidden');
        }
    });
    
    switchView('landing');
});
