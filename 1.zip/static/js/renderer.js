let scene, camera, renderer, houseGroup, controls, currentFloor = 0;
let materials = {};

function init3DModel(data) {
    const container = document.getElementById('three-container');
    if (!container) return;
    
    container.innerHTML = '';

    // Scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87ceeb);
    scene.fog = new THREE.Fog(0x87ceeb, 50, 100);

    // Camera
    const aspect = container.clientWidth / container.clientHeight;
    camera = new THREE.PerspectiveCamera(50, aspect, 0.1, 1000);
    camera.position.set(25, 18, 35);

    // Renderer
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // Controls
    if (typeof THREE.OrbitControls !== 'undefined') {
        controls = new THREE.OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.maxPolarAngle = Math.PI / 2.1;
        controls.minDistance = 10;
        controls.maxDistance = 80;
    }

    // Enhanced Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff5e6, 1.2);
    sunLight.position.set(30, 40, 20);
    sunLight.castShadow = true;
    sunLight.shadow.camera.left = -30;
    sunLight.shadow.camera.right = 30;
    sunLight.shadow.camera.top = 30;
    sunLight.shadow.camera.bottom = -30;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    scene.add(sunLight);

    const fillLight = new THREE.DirectionalLight(0xb3d9ff, 0.4);
    fillLight.position.set(-20, 15, -20);
    scene.add(fillLight);

    // Ground with texture
    const groundGeo = new THREE.PlaneGeometry(80, 80);
    const groundMat = new THREE.MeshStandardMaterial({ 
        color: 0x4a7c59,
        roughness: 0.8,
        metalness: 0.2
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Add landscaping
    addLandscaping();

    // Initialize materials
    initMaterials();

    // Build House
    buildHouse(data);

    // Add UI controls
    addFloorControls(data);

    // Animation Loop
    animate();
}

function initMaterials() {
    // Wall materials with texture-like appearance
    materials.wall = new THREE.MeshStandardMaterial({ 
        color: window.currentColor || 0xf5e6d3,
        roughness: 0.9,
        metalness: 0.1
    });
    
    materials.floor = new THREE.MeshStandardMaterial({ 
        color: 0xd4a574,
        roughness: 0.7,
        metalness: 0.2
    });
    
    materials.window = new THREE.MeshPhysicalMaterial({ 
        color: 0x89cff0,
        transparent: true,
        opacity: 0.4,
        roughness: 0.1,
        metalness: 0.9,
        clearcoat: 1.0
    });
    
    materials.door = new THREE.MeshStandardMaterial({ 
        color: 0x8b4513,
        roughness: 0.6,
        metalness: 0.1
    });
    
    materials.roof = new THREE.MeshStandardMaterial({ 
        color: 0x8b4513,
        roughness: 0.8,
        metalness: 0.2
    });
    
    materials.balcony = new THREE.MeshStandardMaterial({ 
        color: 0x708090,
        roughness: 0.7,
        metalness: 0.3
    });
}

function buildHouse(data) {
    if (houseGroup) scene.remove(houseGroup);
    houseGroup = new THREE.Group();

    // Get user requirements
    const floors = data.floors === 'G' ? 1 : (data.floors === 'G+1' ? 2 : 3);
    const area = parseFloat(data.area) || 1200;
    const constructionType = data.construction_type || 'Standard';
    
    // Fixed dimensions that scale reasonably
    let width = 12;
    let depth = 14;
    
    // Scale based on area (simple scaling)
    if (area < 1000) {
        width = 10;
        depth = 12;
    } else if (area > 2000) {
        width = 14;
        depth = 16;
    }
    
    const heightPerFloor = constructionType === 'Premium' ? 3.8 : (constructionType === 'Basic' ? 3.2 : 3.5);
    const wallThickness = 0.3;

    console.log(`Building: ${floors} floors, ${area} sqft, ${constructionType}, ${width}x${depth}`);

    for (let i = 0; i < floors; i++) {
        const floorY = i * heightPerFloor;
        
        // Create floor slab
        const floorGeo = new THREE.BoxGeometry(width, 0.3, depth);
        const floorMesh = new THREE.Mesh(floorGeo, materials.floor);
        floorMesh.position.y = floorY;
        floorMesh.castShadow = true;
        floorMesh.receiveShadow = true;
        houseGroup.add(floorMesh);

        // Create walls with openings
        createWalls(width, depth, heightPerFloor, floorY, wallThickness, i);
        
        // Add windows
        createWindows(width, depth, heightPerFloor, floorY, i);
        
        // Add door on ground floor
        if (i === 0) {
            createDoor(width, depth, heightPerFloor, floorY);
        }
        
        // Add balcony for upper floors (not for basic construction)
        if (i > 0 && constructionType !== 'Basic') {
            createBalcony(width, depth, floorY, i);
        }
        
        // Add interior elements
        createInteriorSimple(width, depth, heightPerFloor, floorY, i, area, constructionType);
    }

    // Roof
    createRoofSimple(width, depth, floors * heightPerFloor, constructionType);
    
    // Add stairs if multiple floors
    if (floors > 1) {
        createStairs(width, depth, heightPerFloor, floors);
    }

    houseGroup.castShadow = true;
    scene.add(houseGroup);
    
    // Adjust camera
    const maxDim = Math.max(width, depth, floors * heightPerFloor);
    camera.position.set(maxDim * 2, maxDim * 1.5, maxDim * 2.5);
    if (controls) {
        controls.target.set(0, (floors * heightPerFloor) / 2, 0);
        controls.update();
    }
}

// Simplified interior function
function createInteriorSimple(width, depth, height, y, floorIndex, area, constructionType) {
    const wallHeight = height - 0.3;
    const wallThickness = 0.15;
    const scale = 1;
    
    if (floorIndex === 0) {
        // Ground Floor
        
        // Center wall
        const centerWallGeo = new THREE.BoxGeometry(wallThickness, wallHeight, depth);
        const centerWall = new THREE.Mesh(centerWallGeo, materials.wall);
        centerWall.position.set(0, y + wallHeight/2 + 0.15, 0);
        centerWall.castShadow = true;
        houseGroup.add(centerWall);
        
        // Horizontal divider
        const dividerGeo = new THREE.BoxGeometry(width/2, wallHeight, wallThickness);
        const divider = new THREE.Mesh(dividerGeo, materials.wall);
        divider.position.set(-width/4, y + wallHeight/2 + 0.15, 0);
        divider.castShadow = true;
        houseGroup.add(divider);
        
        // Living Room furniture
        addSimpleFurniture(-width/4, y + 0.4, depth/4, 2, 0.8, 1, 0x8b4513); // Sofa
        addSimpleFurniture(-width/4, y + 0.3, depth/4 - 1.5, 1, 0.3, 0.6, 0x654321); // Table
        
        // Kitchen
        addSimpleFurniture(-width/4, y + 0.5, -depth/4, 2, 1, 0.6, 0xa0522d); // Counter
        addSimpleFurniture(-width/2 + 0.5, y + 1, -depth/4, 0.7, 2, 0.7, 0xc0c0c0); // Fridge
        
        // Bedroom
        addSimpleFurniture(width/4, y + 0.4, depth/4, 2, 0.4, 1.5, 0x8b4513); // Bed
        addSimpleFurniture(width/2 - 0.5, y + 1.2, depth/4, 0.6, 2.4, 1.2, 0xa0522d); // Wardrobe
        
    } else {
        // Upper Floors
        
        // Center wall
        const centerWallGeo = new THREE.BoxGeometry(wallThickness, wallHeight, depth);
        const centerWall = new THREE.Mesh(centerWallGeo, materials.wall);
        centerWall.position.set(0, y + wallHeight/2 + 0.15, 0);
        centerWall.castShadow = true;
        houseGroup.add(centerWall);
        
        // Bedrooms
        addSimpleFurniture(-width/4, y + 0.4, 0, 2, 0.4, 1.5, 0x8b4513); // Bed 1
        addSimpleFurniture(-width/2 + 0.5, y + 1.2, depth/4, 0.6, 2.4, 1.2, 0xa0522d); // Wardrobe 1
        
        addSimpleFurniture(width/4, y + 0.4, depth/4, 2, 0.4, 1.5, 0x654321); // Bed 2
        addSimpleFurniture(width/2 - 0.5, y + 1.2, 0, 0.6, 2.4, 1.2, 0xa0522d); // Wardrobe 2
    }
}

// Simple furniture helper
function addSimpleFurniture(x, y, z, w, h, d, color) {
    const furnitureGeo = new THREE.BoxGeometry(w, h, d);
    const furnitureMat = new THREE.MeshStandardMaterial({ 
        color: color,
        roughness: 0.7,
        metalness: 0.1
    });
    const furniture = new THREE.Mesh(furnitureGeo, furnitureMat);
    furniture.position.set(x, y, z);
    furniture.castShadow = true;
    furniture.receiveShadow = true;
    houseGroup.add(furniture);
}

// Simplified roof
function createRoofSimple(w, d, h, constructionType) {
    const type = window.currentRoofType || 'flat';

    if (type === 'flat') {
        const roofGeo = new THREE.BoxGeometry(w + 0.5, 0.3, d + 0.5);
        const roof = new THREE.Mesh(roofGeo, materials.roof);
        roof.position.y = h + 0.15;
        roof.castShadow = true;
        roof.receiveShadow = true;
        houseGroup.add(roof);
        
        // Parapet
        const parapetHeight = 0.8;
        const parapetMat = new THREE.MeshStandardMaterial({ color: 0xd3d3d3, roughness: 0.9 });
        
        const frontParapet = new THREE.BoxGeometry(w + 0.5, parapetHeight, 0.2);
        const fp = new THREE.Mesh(frontParapet, parapetMat);
        fp.position.set(0, h + 0.3 + parapetHeight/2, d/2 + 0.25);
        fp.castShadow = true;
        houseGroup.add(fp);
        
        const bp = fp.clone();
        bp.position.z = -d/2 - 0.25;
        houseGroup.add(bp);
        
        const sideParapet = new THREE.BoxGeometry(0.2, parapetHeight, d + 0.5);
        const lp = new THREE.Mesh(sideParapet, parapetMat);
        lp.position.set(-w/2 - 0.25, h + 0.3 + parapetHeight/2, 0);
        lp.castShadow = true;
        houseGroup.add(lp);
        
        const rp = lp.clone();
        rp.position.x = w/2 + 0.25;
        houseGroup.add(rp);
        
        // Water tank
        if (constructionType !== 'Basic') {
            const tankGeo = new THREE.CylinderGeometry(0.8, 0.8, 1.5, 16);
            const tankMat = new THREE.MeshStandardMaterial({ color: 0x4169e1, roughness: 0.3, metalness: 0.7 });
            const tank = new THREE.Mesh(tankGeo, tankMat);
            tank.position.set(-w/3, h + 0.3 + 0.75, -d/3);
            tank.castShadow = true;
            houseGroup.add(tank);
        }
        
        // Solar panels for Premium
        if (constructionType === 'Premium') {
            for (let i = 0; i < 3; i++) {
                const panelGeo = new THREE.BoxGeometry(1.5, 0.1, 1);
                const panelMat = new THREE.MeshStandardMaterial({ color: 0x1a1a3a, metalness: 0.8, roughness: 0.2 });
                const panel = new THREE.Mesh(panelGeo, panelMat);
                panel.position.set(w/4 + i * 1.7, h + 0.5, 0);
                panel.rotation.x = -0.3;
                panel.castShadow = true;
                houseGroup.add(panel);
            }
        }
    } else {
        const roofHeight = 3;
        const roofGeo = new THREE.ConeGeometry(Math.max(w, d) * 0.8, roofHeight, 4);
        const roof = new THREE.Mesh(roofGeo, materials.roof);
        roof.position.y = h + roofHeight/2;
        roof.rotation.y = Math.PI / 4;
        roof.castShadow = true;
        houseGroup.add(roof);
    }
}

function createWalls(width, depth, height, y, thickness, floorIndex) {
    const wallHeight = height - 0.3;
    
    // Front wall (with door opening on ground floor)
    const frontWall = createWallWithOpenings(width, wallHeight, thickness, 'front', floorIndex === 0);
    frontWall.position.set(0, y + wallHeight/2 + 0.15, depth/2);
    houseGroup.add(frontWall);
    
    // Back wall
    const backWall = createWallWithOpenings(width, wallHeight, thickness, 'back', false);
    backWall.position.set(0, y + wallHeight/2 + 0.15, -depth/2);
    backWall.rotation.y = Math.PI;
    houseGroup.add(backWall);
    
    // Left wall
    const leftWall = createWallWithOpenings(depth, wallHeight, thickness, 'side', false);
    leftWall.position.set(-width/2, y + wallHeight/2 + 0.15, 0);
    leftWall.rotation.y = Math.PI/2;
    houseGroup.add(leftWall);
    
    // Right wall
    const rightWall = createWallWithOpenings(depth, wallHeight, thickness, 'side', false);
    rightWall.position.set(width/2, y + wallHeight/2 + 0.15, 0);
    rightWall.rotation.y = -Math.PI/2;
    houseGroup.add(rightWall);
}

function createWallWithOpenings(width, height, thickness, type, hasDoor) {
    const wall = new THREE.Group();
    
    if (type === 'front' && hasDoor) {
        // Wall segments around door
        const doorWidth = 1.2;
        const doorHeight = 2.2;
        
        // Left segment
        const leftGeo = new THREE.BoxGeometry((width - doorWidth)/2, height, thickness);
        const leftWall = new THREE.Mesh(leftGeo, materials.wall);
        leftWall.position.x = -(width - doorWidth)/4 - doorWidth/2;
        leftWall.castShadow = true;
        leftWall.receiveShadow = true;
        wall.add(leftWall);
        
        // Right segment
        const rightWall = leftWall.clone();
        rightWall.position.x = (width - doorWidth)/4 + doorWidth/2;
        wall.add(rightWall);
        
        // Top segment
        const topGeo = new THREE.BoxGeometry(doorWidth, height - doorHeight, thickness);
        const topWall = new THREE.Mesh(topGeo, materials.wall);
        topWall.position.y = doorHeight/2 + (height - doorHeight)/2;
        topWall.castShadow = true;
        topWall.receiveShadow = true;
        wall.add(topWall);
    } else {
        // Solid wall
        const wallGeo = new THREE.BoxGeometry(width, height, thickness);
        const wallMesh = new THREE.Mesh(wallGeo, materials.wall);
        wallMesh.castShadow = true;
        wallMesh.receiveShadow = true;
        wall.add(wallMesh);
    }
    
    return wall;
}

function createWindows(width, depth, height, y, floorIndex) {
    const windowWidth = 1.5;
    const windowHeight = 1.8;
    const windowY = y + height - 1.5;
    
    // Front windows
    createWindow(-width/3, windowY, depth/2 + 0.15, windowWidth, windowHeight);
    createWindow(width/3, windowY, depth/2 + 0.15, windowWidth, windowHeight);
    
    // Side windows
    createWindow(-width/2 - 0.15, windowY, 0, windowWidth, windowHeight, Math.PI/2);
    createWindow(width/2 + 0.15, windowY, 0, windowWidth, windowHeight, Math.PI/2);
}

function createWindow(x, y, z, width, height, rotation = 0) {
    const frameThickness = 0.1;
    
    // Window frame
    const frameGeo = new THREE.BoxGeometry(width + 0.2, height + 0.2, frameThickness);
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x333333 });
    const frame = new THREE.Mesh(frameGeo, frameMat);
    frame.position.set(x, y, z);
    if (rotation) frame.rotation.y = rotation;
    frame.castShadow = true;
    houseGroup.add(frame);
    
    // Glass pane
    const glassGeo = new THREE.BoxGeometry(width, height, 0.05);
    const glass = new THREE.Mesh(glassGeo, materials.window);
    glass.position.set(x, y, z);
    if (rotation) glass.rotation.y = rotation;
    houseGroup.add(glass);
    
    // Window divider
    const dividerGeo = new THREE.BoxGeometry(0.05, height, 0.05);
    const divider = new THREE.Mesh(dividerGeo, frameMat);
    divider.position.set(x, y, z);
    if (rotation) divider.rotation.y = rotation;
    houseGroup.add(divider);
}

function createDoor(width, depth, height, y) {
    const doorWidth = 1.2;
    const doorHeight = 2.2;
    
    // Door
    const doorGeo = new THREE.BoxGeometry(doorWidth, doorHeight, 0.1);
    const door = new THREE.Mesh(doorGeo, materials.door);
    door.position.set(0, y + doorHeight/2 + 0.15, depth/2 + 0.15);
    door.castShadow = true;
    houseGroup.add(door);
    
    // Door handle
    const handleGeo = new THREE.SphereGeometry(0.08, 16, 16);
    const handleMat = new THREE.MeshStandardMaterial({ 
        color: 0xffd700,
        metalness: 0.9,
        roughness: 0.2
    });
    const handle = new THREE.Mesh(handleGeo, handleMat);
    handle.position.set(doorWidth/3, y + doorHeight/2 + 0.15, depth/2 + 0.2);
    houseGroup.add(handle);
}

function createBalcony(width, depth, y, floorIndex) {
    const balconyDepth = 2;
    const balconyWidth = width * 0.6;
    
    // Balcony floor
    const floorGeo = new THREE.BoxGeometry(balconyWidth, 0.2, balconyDepth);
    const balconyFloor = new THREE.Mesh(floorGeo, materials.balcony);
    balconyFloor.position.set(0, y, depth/2 + balconyDepth/2);
    balconyFloor.castShadow = true;
    balconyFloor.receiveShadow = true;
    houseGroup.add(balconyFloor);
    
    // Railing
    const railingHeight = 1.0;
    const railingThickness = 0.05;
    
    // Front railing
    const frontRailGeo = new THREE.BoxGeometry(balconyWidth, railingThickness, railingThickness);
    const frontRail = new THREE.Mesh(frontRailGeo, materials.balcony);
    frontRail.position.set(0, y + railingHeight, depth/2 + balconyDepth);
    houseGroup.add(frontRail);
    
    // Side railings
    const sideRailGeo = new THREE.BoxGeometry(railingThickness, railingThickness, balconyDepth);
    const leftRail = new THREE.Mesh(sideRailGeo, materials.balcony);
    leftRail.position.set(-balconyWidth/2, y + railingHeight, depth/2 + balconyDepth/2);
    houseGroup.add(leftRail);
    
    const rightRail = leftRail.clone();
    rightRail.position.x = balconyWidth/2;
    houseGroup.add(rightRail);
    
    // Vertical posts
    for (let i = -1; i <= 1; i++) {
        const postGeo = new THREE.BoxGeometry(railingThickness, railingHeight, railingThickness);
        const post = new THREE.Mesh(postGeo, materials.balcony);
        post.position.set(i * balconyWidth/3, y + railingHeight/2, depth/2 + balconyDepth);
        houseGroup.add(post);
    }
}

function createInterior(width, depth, height, y, floorIndex, area, constructionType) {
    // Create room divisions with walls
    const wallHeight = height - 0.3;
    const wallThickness = 0.15;
    
    // Determine number of rooms based on area
    const areaPerFloor = area / (floorIndex + 1);
    const isLargeHouse = areaPerFloor > 1500;
    const isPremium = constructionType === 'Premium';
    
    // Room layout based on floor
    if (floorIndex === 0) {
        // Ground Floor: Living Room, Kitchen, Bedroom, Bathroom
        
        // Vertical dividing wall (center)
        const centerWallGeo = new THREE.BoxGeometry(wallThickness, wallHeight, depth);
        const centerWall = new THREE.Mesh(centerWallGeo, materials.wall);
        centerWall.position.set(0, y + wallHeight/2 + 0.15, 0);
        centerWall.castShadow = true;
        centerWall.receiveShadow = true;
        houseGroup.add(centerWall);
        
        // Horizontal dividing wall (left side)
        const leftDividerGeo = new THREE.BoxGeometry(width/2, wallHeight, wallThickness);
        const leftDivider = new THREE.Mesh(leftDividerGeo, materials.wall);
        leftDivider.position.set(-width/4, y + wallHeight/2 + 0.15, 0);
        leftDivider.castShadow = true;
        leftDivider.receiveShadow = true;
        houseGroup.add(leftDivider);
        
        // Living Room (front left) - Scale furniture based on room size
        const furnitureScale = Math.min(width, depth) / 12;
        addSofa(-width/4, y + 0.4, depth/4, 0x8b4513, furnitureScale);
        addTable(-width/4, y + 0.3, depth/4 - 1, 0x654321, furnitureScale);
        
        if (isPremium) {
            addTV(-width/2 + 0.3, y + 1, depth/4, 0x1a1a1a, furnitureScale);
        }
        
        // Kitchen (back left)
        addKitchenCounter(-width/4, y + 0.5, -depth/4, 0xa0522d, furnitureScale);
        addRefrigerator(-width/2 + 0.5, y + 1, -depth/4, 0xc0c0c0, furnitureScale);
        
        // Bedroom (front right)
        addBed(width/4, y + 0.4, depth/4, 0x8b4513, furnitureScale);
        addWardrobe(width/2 - 0.5, y + 1.2, depth/4, 0xa0522d, furnitureScale);
        
        // Bathroom (back right)
        addBathroom(width/4, y, -depth/4, furnitureScale);
        
        // Add extra room for large houses
        if (isLargeHouse) {
            const extraDividerGeo = new THREE.BoxGeometry(width/2, wallHeight, wallThickness);
            const extraDivider = new THREE.Mesh(extraDividerGeo, materials.wall);
            extraDivider.position.set(width/4, y + wallHeight/2 + 0.15, 0);
            extraDivider.castShadow = true;
            houseGroup.add(extraDivider);
            
            // Study/Office
            addStudyTable(width/4, y + 0.8, depth/4, 0x8b4513, furnitureScale);
        }
        
    } else {
        // Upper Floors: Bedrooms
        
        // Vertical dividing wall
        const centerWallGeo = new THREE.BoxGeometry(wallThickness, wallHeight, depth);
        const centerWall = new THREE.Mesh(centerWallGeo, materials.wall);
        centerWall.position.set(0, y + wallHeight/2 + 0.15, 0);
        centerWall.castShadow = true;
        houseGroup.add(centerWall);
        
        const furnitureScale = Math.min(width, depth) / 12;
        
        // Master Bedroom (left)
        addBed(-width/4, y + 0.4, 0, 0x8b4513, furnitureScale);
        addWardrobe(-width/2 + 0.5, y + 1.2, depth/4, 0xa0522d, furnitureScale);
        
        if (isPremium) {
            addDressingTable(-width/4, y + 0.8, -depth/4, 0x8b4513, furnitureScale);
        }
        
        // Bedroom 2 (right)
        addBed(width/4, y + 0.4, depth/4, 0x654321, furnitureScale);
        addWardrobe(width/2 - 0.5, y + 1.2, 0, 0xa0522d, furnitureScale);
        addStudyTable(width/4, y + 0.8, -depth/4, 0x8b4513, furnitureScale);
        
        // Add extra bedroom for large houses
        if (isLargeHouse) {
            const extraDividerGeo = new THREE.BoxGeometry(wallThickness, wallHeight, depth/2);
            const extraDivider = new THREE.Mesh(extraDividerGeo, materials.wall);
            extraDivider.position.set(-width/4, y + wallHeight/2 + 0.15, -depth/4);
            extraDivider.castShadow = true;
            houseGroup.add(extraDivider);
            
            addBed(-width/4, y + 0.4, -depth/4, 0x654321, furnitureScale * 0.8);
        }
    }
}

// Updated furniture functions with scale parameter
function addSofa(x, y, z, color, scale = 1) {
    const sofaGeo = new THREE.BoxGeometry(2 * scale, 0.8 * scale, 1 * scale);
    const sofaMat = new THREE.MeshStandardMaterial({ color: color, roughness: 0.8 });
    const sofa = new THREE.Mesh(sofaGeo, sofaMat);
    sofa.position.set(x, y, z);
    sofa.castShadow = true;
    sofa.receiveShadow = true;
    houseGroup.add(sofa);
    
    const backGeo = new THREE.BoxGeometry(2 * scale, 0.6 * scale, 0.2 * scale);
    const back = new THREE.Mesh(backGeo, sofaMat);
    back.position.set(x, y + 0.7 * scale, z - 0.4 * scale);
    back.castShadow = true;
    houseGroup.add(back);
}

function addTable(x, y, z, color, scale = 1) {
    const tableGeo = new THREE.BoxGeometry(1 * scale, 0.1 * scale, 0.6 * scale);
    const tableMat = new THREE.MeshStandardMaterial({ color: color, roughness: 0.6 });
    const table = new THREE.Mesh(tableGeo, tableMat);
    table.position.set(x, y, z);
    table.castShadow = true;
    table.receiveShadow = true;
    houseGroup.add(table);
    
    for (let i = 0; i < 4; i++) {
        const legGeo = new THREE.CylinderGeometry(0.05 * scale, 0.05 * scale, 0.3 * scale, 8);
        const leg = new THREE.Mesh(legGeo, tableMat);
        const xOffset = i % 2 === 0 ? -0.4 * scale : 0.4 * scale;
        const zOffset = i < 2 ? -0.25 * scale : 0.25 * scale;
        leg.position.set(x + xOffset, y - 0.2 * scale, z + zOffset);
        leg.castShadow = true;
        houseGroup.add(leg);
    }
}

function addTV(x, y, z, color, scale = 1) {
    const tvGeo = new THREE.BoxGeometry(0.1 * scale, 1 * scale, 1.5 * scale);
    const tvMat = new THREE.MeshStandardMaterial({ color: color, roughness: 0.3, metalness: 0.5 });
    const tv = new THREE.Mesh(tvGeo, tvMat);
    tv.position.set(x, y, z);
    tv.castShadow = true;
    houseGroup.add(tv);
}

function addBed(x, y, z, color, scale = 1) {
    const bedGeo = new THREE.BoxGeometry(2 * scale, 0.4 * scale, 1.5 * scale);
    const bedMat = new THREE.MeshStandardMaterial({ color: color, roughness: 0.8 });
    const bed = new THREE.Mesh(bedGeo, bedMat);
    bed.position.set(x, y, z);
    bed.castShadow = true;
    bed.receiveShadow = true;
    houseGroup.add(bed);
    
    const headGeo = new THREE.BoxGeometry(2 * scale, 0.8 * scale, 0.2 * scale);
    const head = new THREE.Mesh(headGeo, bedMat);
    head.position.set(x, y + 0.6 * scale, z - 0.65 * scale);
    head.castShadow = true;
    houseGroup.add(head);
}

function addWardrobe(x, y, z, color, scale = 1) {
    const wardrobeGeo = new THREE.BoxGeometry(0.6 * scale, 2.4 * scale, 1.2 * scale);
    const wardrobeMat = new THREE.MeshStandardMaterial({ color: color, roughness: 0.7 });
    const wardrobe = new THREE.Mesh(wardrobeGeo, wardrobeMat);
    wardrobe.position.set(x, y, z);
    wardrobe.castShadow = true;
    wardrobe.receiveShadow = true;
    houseGroup.add(wardrobe);
}

function addKitchenCounter(x, y, z, color, scale = 1) {
    const counterGeo = new THREE.BoxGeometry(2 * scale, 1 * scale, 0.6 * scale);
    const counterMat = new THREE.MeshStandardMaterial({ color: color, roughness: 0.5 });
    const counter = new THREE.Mesh(counterGeo, counterMat);
    counter.position.set(x, y, z);
    counter.castShadow = true;
    counter.receiveShadow = true;
    houseGroup.add(counter);
    
    const sinkGeo = new THREE.BoxGeometry(0.5 * scale, 0.2 * scale, 0.4 * scale);
    const sinkMat = new THREE.MeshStandardMaterial({ color: 0xc0c0c0, metalness: 0.8, roughness: 0.2 });
    const sink = new THREE.Mesh(sinkGeo, sinkMat);
    sink.position.set(x, y + 0.6 * scale, z);
    houseGroup.add(sink);
}

function addRefrigerator(x, y, z, color, scale = 1) {
    const fridgeGeo = new THREE.BoxGeometry(0.7 * scale, 2 * scale, 0.7 * scale);
    const fridgeMat = new THREE.MeshStandardMaterial({ color: color, metalness: 0.6, roughness: 0.3 });
    const fridge = new THREE.Mesh(fridgeGeo, fridgeMat);
    fridge.position.set(x, y, z);
    fridge.castShadow = true;
    houseGroup.add(fridge);
}

function addBathroom(x, y, z, scale = 1) {
    const toiletGeo = new THREE.CylinderGeometry(0.25 * scale, 0.25 * scale, 0.5 * scale, 16);
    const toiletMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 });
    const toilet = new THREE.Mesh(toiletGeo, toiletMat);
    toilet.position.set(x - 0.5 * scale, y + 0.25 * scale, z - 0.5 * scale);
    toilet.castShadow = true;
    houseGroup.add(toilet);
    
    const sinkGeo = new THREE.CylinderGeometry(0.2 * scale, 0.15 * scale, 0.1 * scale, 16);
    const sink = new THREE.Mesh(sinkGeo, toiletMat);
    sink.position.set(x + 0.5 * scale, y + 0.8 * scale, z - 0.5 * scale);
    houseGroup.add(sink);
    
    const showerGeo = new THREE.BoxGeometry(0.8 * scale, 2 * scale, 0.8 * scale);
    const showerMat = new THREE.MeshStandardMaterial({ color: 0xe0e0e0, transparent: true, opacity: 0.3 });
    const shower = new THREE.Mesh(showerGeo, showerMat);
    shower.position.set(x, y + 1 * scale, z + 0.5 * scale);
    houseGroup.add(shower);
}

function addDressingTable(x, y, z, color, scale = 1) {
    const tableGeo = new THREE.BoxGeometry(1 * scale, 0.8 * scale, 0.4 * scale);
    const tableMat = new THREE.MeshStandardMaterial({ color: color, roughness: 0.6 });
    const table = new THREE.Mesh(tableGeo, tableMat);
    table.position.set(x, y, z);
    table.castShadow = true;
    houseGroup.add(table);
    
    const mirrorGeo = new THREE.BoxGeometry(0.8 * scale, 1 * scale, 0.05 * scale);
    const mirrorMat = new THREE.MeshStandardMaterial({ color: 0xaaaaaa, metalness: 0.9, roughness: 0.1 });
    const mirror = new THREE.Mesh(mirrorGeo, mirrorMat);
    mirror.position.set(x, y + 1 * scale, z - 0.25 * scale);
    houseGroup.add(mirror);
}

function addStudyTable(x, y, z, color, scale = 1) {
    const tableGeo = new THREE.BoxGeometry(1.2 * scale, 0.8 * scale, 0.6 * scale);
    const tableMat = new THREE.MeshStandardMaterial({ color: color, roughness: 0.6 });
    const table = new THREE.Mesh(tableGeo, tableMat);
    table.position.set(x, y, z);
    table.castShadow = true;
    table.receiveShadow = true;
    houseGroup.add(table);
    
    const chairGeo = new THREE.BoxGeometry(0.4 * scale, 0.5 * scale, 0.4 * scale);
    const chair = new THREE.Mesh(chairGeo, tableMat);
    chair.position.set(x, y - 0.2 * scale, z + 0.5 * scale);
    chair.castShadow = true;
    houseGroup.add(chair);
}

function createStairs(width, depth, heightPerFloor, floors) {
    if (floors === 1) return;
    
    const stairWidth = 1.2;
    const stairDepth = 0.3;
    const stairHeight = 0.2;
    const numSteps = Math.floor(heightPerFloor / stairHeight);
    
    for (let floor = 0; floor < floors - 1; floor++) {
        for (let i = 0; i < numSteps; i++) {
            const stepGeo = new THREE.BoxGeometry(stairWidth, stairHeight, stairDepth);
            const stepMat = new THREE.MeshStandardMaterial({ 
                color: 0x696969,
                roughness: 0.8
            });
            const step = new THREE.Mesh(stepGeo, stepMat);
            step.position.set(
                -width/2 + 1,
                floor * heightPerFloor + i * stairHeight + stairHeight/2,
                -depth/2 + 1 + i * stairDepth
            );
            step.castShadow = true;
            step.receiveShadow = true;
            houseGroup.add(step);
        }
    }
}

function createRoof(w, d, h, constructionType) {
    const type = window.currentRoofType || (constructionType === 'Premium' ? 'flat' : 'flat');

    if (type === 'flat') {
        // Flat roof with parapet
        const roofGeo = new THREE.BoxGeometry(w + 0.5, 0.3, d + 0.5);
        const roof = new THREE.Mesh(roofGeo, materials.roof);
        roof.position.y = h + 0.15;
        roof.castShadow = true;
        roof.receiveShadow = true;
        houseGroup.add(roof);
        
        // Parapet walls
        const parapetHeight = constructionType === 'Premium' ? 1.0 : 0.8;
        const parapetThickness = 0.2;
        
        const parapetMat = new THREE.MeshStandardMaterial({ 
            color: 0xd3d3d3,
            roughness: 0.9
        });
        
        // Front parapet
        const frontParapet = new THREE.BoxGeometry(w + 0.5, parapetHeight, parapetThickness);
        const fp = new THREE.Mesh(frontParapet, parapetMat);
        fp.position.set(0, h + 0.3 + parapetHeight/2, d/2 + 0.25);
        fp.castShadow = true;
        houseGroup.add(fp);
        
        // Back parapet
        const bp = fp.clone();
        bp.position.z = -d/2 - 0.25;
        houseGroup.add(bp);
        
        // Left parapet
        const sideParapet = new THREE.BoxGeometry(parapetThickness, parapetHeight, d + 0.5);
        const lp = new THREE.Mesh(sideParapet, parapetMat);
        lp.position.set(-w/2 - 0.25, h + 0.3 + parapetHeight/2, 0);
        lp.castShadow = true;
        houseGroup.add(lp);
        
        // Right parapet
        const rp = lp.clone();
        rp.position.x = w/2 + 0.25;
        houseGroup.add(rp);
        
        // Water tank (only for Standard and Premium)
        if (constructionType !== 'Basic') {
            const tankSize = constructionType === 'Premium' ? 1.0 : 0.8;
            const tankGeo = new THREE.CylinderGeometry(tankSize, tankSize, 1.5, 16);
            const tankMat = new THREE.MeshStandardMaterial({ 
                color: 0x4169e1,
                roughness: 0.3,
                metalness: 0.7
            });
            const tank = new THREE.Mesh(tankGeo, tankMat);
            tank.position.set(-w/3, h + 0.3 + 0.75, -d/3);
            tank.castShadow = true;
            houseGroup.add(tank);
        }
        
        // Solar panels for Premium
        if (constructionType === 'Premium') {
            for (let i = 0; i < 3; i++) {
                const panelGeo = new THREE.BoxGeometry(1.5, 0.1, 1);
                const panelMat = new THREE.MeshStandardMaterial({ 
                    color: 0x1a1a3a,
                    metalness: 0.8,
                    roughness: 0.2
                });
                const panel = new THREE.Mesh(panelGeo, panelMat);
                panel.position.set(w/4 + i * 1.7, h + 0.5, 0);
                panel.rotation.x = -0.3;
                panel.castShadow = true;
                houseGroup.add(panel);
            }
        }
        
    } else {
        // Sloped roof
        const roofHeight = 3;
        const roofGeo = new THREE.ConeGeometry(Math.max(w, d) * 0.8, roofHeight, 4);
        const roof = new THREE.Mesh(roofGeo, materials.roof);
        roof.position.y = h + roofHeight/2;
        roof.rotation.y = Math.PI / 4;
        roof.castShadow = true;
        houseGroup.add(roof);
    }
}

function addLandscaping() {
    // Add trees
    for (let i = 0; i < 6; i++) {
        const angle = (i / 6) * Math.PI * 2;
        const radius = 25 + Math.random() * 10;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        addTree(x, z);
    }
    
    // Add pathway
    const pathGeo = new THREE.BoxGeometry(3, 0.1, 20);
    const pathMat = new THREE.MeshStandardMaterial({ 
        color: 0x8b7355,
        roughness: 0.9
    });
    const path = new THREE.Mesh(pathGeo, pathMat);
    path.position.set(0, 0.05, 15);
    path.receiveShadow = true;
    scene.add(path);
    
    // Add garden beds
    for (let i = -1; i <= 1; i += 2) {
        const bedGeo = new THREE.BoxGeometry(8, 0.3, 8);
        const bedMat = new THREE.MeshStandardMaterial({ 
            color: 0x654321,
            roughness: 1.0
        });
        const bed = new THREE.Mesh(bedGeo, bedMat);
        bed.position.set(i * 12, 0.15, 5);
        bed.receiveShadow = true;
        scene.add(bed);
        
        // Add bushes
        for (let j = 0; j < 3; j++) {
            const bushGeo = new THREE.SphereGeometry(0.5 + Math.random() * 0.3, 8, 8);
            const bushMat = new THREE.MeshStandardMaterial({ 
                color: 0x228b22,
                roughness: 1.0
            });
            const bush = new THREE.Mesh(bushGeo, bushMat);
            bush.position.set(
                i * 12 + (Math.random() - 0.5) * 6,
                0.3,
                5 + (Math.random() - 0.5) * 6
            );
            bush.castShadow = true;
            scene.add(bush);
        }
    }
}

function addTree(x, z) {
    // Trunk
    const trunkGeo = new THREE.CylinderGeometry(0.3, 0.4, 3, 8);
    const trunkMat = new THREE.MeshStandardMaterial({ 
        color: 0x8b4513,
        roughness: 1.0
    });
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.set(x, 1.5, z);
    trunk.castShadow = true;
    scene.add(trunk);
    
    // Foliage
    const foliageGeo = new THREE.SphereGeometry(1.5, 8, 8);
    const foliageMat = new THREE.MeshStandardMaterial({ 
        color: 0x228b22,
        roughness: 1.0
    });
    const foliage = new THREE.Mesh(foliageGeo, foliageMat);
    foliage.position.set(x, 4, z);
    foliage.castShadow = true;
    scene.add(foliage);
}

function addFloorControls(data) {
    const floors = data.floors === 'G' ? 1 : (data.floors === 'G+1' ? 2 : 3);
    if (floors === 1) return;
    
    const container = document.getElementById('three-container');
    if (!container) return;
    
    // Remove existing controls
    const existing = container.querySelector('.floor-selector');
    if (existing) existing.remove();
    
    // Create floor selector
    const selector = document.createElement('div');
    selector.className = 'floor-selector';
    selector.style.cssText = `
        position: absolute;
        top: 20px;
        right: 20px;
        background: rgba(255, 255, 255, 0.95);
        padding: 15px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        font-family: Poppins, sans-serif;
        z-index: 10;
    `;
    
    selector.innerHTML = `
        <div style="font-weight: 600; margin-bottom: 10px; color: #333;">Floor View</div>
        ${Array.from({length: floors}, (_, i) => `
            <button onclick="highlightFloor(${i})" style="
                display: block;
                width: 100%;
                padding: 8px 12px;
                margin: 5px 0;
                border: 2px solid ${i === 0 ? '#6366f1' : '#ddd'};
                background: ${i === 0 ? '#6366f1' : 'white'};
                color: ${i === 0 ? 'white' : '#333'};
                border-radius: 6px;
                cursor: pointer;
                font-weight: 500;
                transition: all 0.3s;
            " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                ${i === 0 ? 'Ground Floor' : `Floor ${i}`}
            </button>
        `).join('')}
        <button onclick="highlightFloor(-1)" style="
            display: block;
            width: 100%;
            padding: 8px 12px;
            margin-top: 10px;
            border: 2px solid #10b981;
            background: white;
            color: #10b981;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
        ">Show All</button>
    `;
    
    container.appendChild(selector);
}

function animate() {
    requestAnimationFrame(animate);
    if (controls) controls.update();
    if (renderer && scene && camera) {
        renderer.render(scene, camera);
    }
}

function onWindowResize() {
    const container = document.getElementById('three-container');
    if (!container || !camera || !renderer) return;
    camera.aspect = container.clientWidth / container.clientHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(container.clientWidth, container.clientHeight);
}

window.addEventListener('resize', onWindowResize);

// Interactivity
window.updateWallColor = function (color) {
    const hexColor = parseInt(color.replace('#', '0x'));
    window.currentColor = hexColor;
    if (materials.wall) {
        materials.wall.color.setHex(hexColor);
    }
}

window.updateRoof = function (type) {
    window.currentRoofType = type;
    if (houseGroup && projectContext) buildHouse(projectContext);
}

window.highlightFloor = function(floorIndex) {
    if (!houseGroup) return;
    
    currentFloor = floorIndex;
    
    // Update button styles
    const buttons = document.querySelectorAll('.floor-selector button');
    buttons.forEach((btn, idx) => {
        if (idx === floorIndex || (floorIndex === -1 && idx === buttons.length - 1)) {
            btn.style.background = '#6366f1';
            btn.style.color = 'white';
            btn.style.borderColor = '#6366f1';
        } else {
            btn.style.background = 'white';
            btn.style.color = '#333';
            btn.style.borderColor = '#ddd';
        }
    });
    
    // Highlight effect - make other floors semi-transparent
    houseGroup.children.forEach((child) => {
        if (child.material) {
            if (floorIndex === -1) {
                // Show all
                child.material.opacity = 1;
                child.material.transparent = false;
            } else {
                // Check if this object belongs to the selected floor
                const objFloor = Math.floor(child.position.y / 3.5);
                if (objFloor === floorIndex) {
                    child.material.opacity = 1;
                    child.material.transparent = false;
                } else {
                    child.material.opacity = 0.2;
                    child.material.transparent = true;
                }
            }
        }
    });
}

// Download 3D view as image
window.download3DView = function() {
    if (!renderer) return;
    
    const link = document.createElement('a');
    link.download = 'BuildWise_3D_Model.png';
    link.href = renderer.domElement.toDataURL('image/png');
    link.click();
    
    alert('✓ 3D view downloaded successfully!');
}
