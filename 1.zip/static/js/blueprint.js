let blueprintData = null;

function initBlueprint(data, breakdown) {
    blueprintData = data;
    console.log('Blueprint initialized with data:', data);
}

function drawBlueprint() {
    const canvas = document.getElementById('blueprintCanvas');
    if (!canvas || !canvas.offsetParent) return;

    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Clear canvas
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, width, height);

    // Get project details
    const area = projectContext && projectContext.area ? parseFloat(projectContext.area) : 1200;
    const floors = projectContext && projectContext.floors ? projectContext.floors : 'G';
    const vastu = projectContext && projectContext.vastu !== undefined ? projectContext.vastu : true;

    // Calculate dimensions (assuming square-ish plot)
    const plotWidth = Math.sqrt(area * 1.2); // Slightly rectangular
    const plotDepth = area / plotWidth;
    
    // Scale to fit canvas with margins
    const margin = 60;
    const scale = Math.min((width - 2 * margin) / plotWidth, (height - 2 * margin) / plotDepth);
    const offsetX = (width - plotWidth * scale) / 2;
    const offsetY = (height - plotDepth * scale) / 2;

    // Helper function to scale coordinates
    function scaleX(x) { return offsetX + x * scale; }
    function scaleY(y) { return offsetY + y * scale; }

    // Draw title and info
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 20px Poppins';
    ctx.fillText('FLOOR PLAN - ' + (vastu ? 'VASTU COMPLIANT' : 'STANDARD LAYOUT'), 20, 30);
    
    ctx.font = '14px Poppins';
    ctx.fillStyle = '#94a3b8';
    ctx.fillText(`Area: ${area} sq ft | Floors: ${floors} | Scale: 1:${Math.round(100/scale)}`, 20, 50);

    // Draw compass
    drawCompass(ctx, width - 50, 50);

    // Draw outer boundary
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    ctx.strokeRect(scaleX(0), scaleY(0), plotWidth * scale, plotDepth * scale);

    // Draw detailed room layout
    if (vastu) {
        drawVastuLayout(ctx, scaleX, scaleY, plotWidth, plotDepth, scale);
    } else {
        drawStandardLayout(ctx, scaleX, scaleY, plotWidth, plotDepth, scale);
    }

    // Draw dimensions
    drawDimensions(ctx, scaleX, scaleY, plotWidth, plotDepth, scale);

    // Draw legend
    drawLegend(ctx, 20, height - 120);
}

function drawCompass(ctx, x, y) {
    const size = 35;
    
    // Circle
    ctx.strokeStyle = '#6366f1';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.stroke();

    // North arrow
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.moveTo(x, y - size);
    ctx.lineTo(x - 8, y);
    ctx.lineTo(x + 8, y);
    ctx.closePath();
    ctx.fill();

    // Labels
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 14px Poppins';
    ctx.textAlign = 'center';
    ctx.fillText('N', x, y - size - 10);
    ctx.fillText('S', x, y + size + 20);
    ctx.fillText('E', x + size + 15, y + 5);
    ctx.fillText('W', x - size - 15, y + 5);
}

function drawVastuLayout(ctx, scaleX, scaleY, width, depth, scale) {
    const midX = width / 2;
    const midY = depth / 2;

    // Draw internal walls
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    
    // Vertical center wall
    ctx.beginPath();
    ctx.moveTo(scaleX(midX), scaleY(0));
    ctx.lineTo(scaleX(midX), scaleY(depth));
    ctx.stroke();

    // Horizontal center wall
    ctx.beginPath();
    ctx.moveTo(scaleX(0), scaleY(midY));
    ctx.lineTo(scaleX(width), scaleY(midY));
    ctx.stroke();

    // Draw rooms with colors
    const rooms = [
        { x: 0, y: 0, w: midX, h: midY, name: 'LIVING ROOM\n(North-East)', color: '#10b98120', icon: '🛋️' },
        { x: midX, y: 0, w: midX, h: midY, name: 'BEDROOM 1\n(North-West)', color: '#6366f120', icon: '🛏️' },
        { x: 0, y: midY, w: midX, h: midY, name: 'KITCHEN\n(South-East)', color: '#f59e0b20', icon: '🍳' },
        { x: midX, y: midY, w: midX, h: midY, name: 'MASTER BEDROOM\n(South-West)', color: '#8b5cf620', icon: '👑' }
    ];

    rooms.forEach(room => {
        // Fill room with color
        ctx.fillStyle = room.color;
        ctx.fillRect(scaleX(room.x), scaleY(room.y), room.w * scale, room.h * scale);

        // Draw room name
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 16px Poppins';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        const centerX = scaleX(room.x + room.w / 2);
        const centerY = scaleY(room.y + room.h / 2);
        
        // Icon
        ctx.font = '32px Arial';
        ctx.fillText(room.icon, centerX, centerY - 20);
        
        // Room name
        ctx.font = 'bold 14px Poppins';
        const lines = room.name.split('\n');
        lines.forEach((line, i) => {
            ctx.fillText(line, centerX, centerY + 15 + i * 18);
        });
    });

    // Draw doors
    drawDoor(ctx, scaleX(width), scaleY(midY - 2), scaleX(width), scaleY(midY + 2), 'Main Door');
    drawDoor(ctx, scaleX(midX - 1.5), scaleY(midY), scaleX(midX + 1.5), scaleY(midY), '');

    // Draw windows
    drawWindow(ctx, scaleX(2), scaleY(0), scaleX(8), scaleY(0));
    drawWindow(ctx, scaleX(width - 8), scaleY(0), scaleX(width - 2), scaleY(0));
    drawWindow(ctx, scaleX(0), scaleY(5), scaleX(0), scaleY(11));
    drawWindow(ctx, scaleX(width), scaleY(depth - 11), scaleX(width), scaleY(depth - 5));

    // Draw bathroom
    const bathWidth = width * 0.2;
    const bathDepth = depth * 0.15;
    ctx.strokeStyle = '#94a3b8';
    ctx.setLineDash([5, 5]);
    ctx.strokeRect(scaleX(midX - bathWidth/2), scaleY(midY - bathDepth/2), bathWidth * scale, bathDepth * scale);
    ctx.setLineDash([]);
    
    ctx.fillStyle = '#94a3b8';
    ctx.font = '12px Poppins';
    ctx.fillText('🚿 BATHROOM', scaleX(midX), scaleY(midY));
}

function drawStandardLayout(ctx, scaleX, scaleY, width, depth, scale) {
    // Similar to Vastu but different arrangement
    drawVastuLayout(ctx, scaleX, scaleY, width, depth, scale);
}

function drawDoor(ctx, x1, y1, x2, y2, label) {
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();

    if (label) {
        ctx.fillStyle = '#10b981';
        ctx.font = 'bold 11px Poppins';
        ctx.textAlign = 'center';
        ctx.fillText(label, (x1 + x2) / 2, (y1 + y2) / 2 - 10);
    }
}

function drawWindow(ctx, x1, y1, x2, y2) {
    ctx.strokeStyle = '#3b82f6';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();

    // Window lines
    const segments = 3;
    for (let i = 1; i < segments; i++) {
        const t = i / segments;
        const x = x1 + (x2 - x1) * t;
        const y = y1 + (y2 - y1) * t;
        ctx.strokeStyle = '#60a5fa';
        ctx.lineWidth = 1;
        ctx.beginPath();
        if (x1 === x2) {
            ctx.moveTo(x - 3, y);
            ctx.lineTo(x + 3, y);
        } else {
            ctx.moveTo(x, y - 3);
            ctx.lineTo(x, y + 3);
        }
        ctx.stroke();
    }
}

function drawDimensions(ctx, scaleX, scaleY, width, depth, scale) {
    ctx.strokeStyle = '#f59e0b';
    ctx.fillStyle = '#f59e0b';
    ctx.lineWidth = 1;
    ctx.font = '12px Poppins';
    ctx.textAlign = 'center';

    // Width dimension
    const y = scaleY(depth) + 30;
    ctx.beginPath();
    ctx.moveTo(scaleX(0), y);
    ctx.lineTo(scaleX(width), y);
    ctx.stroke();
    
    // Arrows
    drawArrow(ctx, scaleX(0), y, -1, 0);
    drawArrow(ctx, scaleX(width), y, 1, 0);
    
    ctx.fillText(`${width.toFixed(1)} ft`, scaleX(width / 2), y + 15);

    // Depth dimension
    const x = scaleX(width) + 30;
    ctx.beginPath();
    ctx.moveTo(x, scaleY(0));
    ctx.lineTo(x, scaleY(depth));
    ctx.stroke();
    
    drawArrow(ctx, x, scaleY(0), 0, -1);
    drawArrow(ctx, x, scaleY(depth), 0, 1);
    
    ctx.save();
    ctx.translate(x + 15, scaleY(depth / 2));
    ctx.rotate(-Math.PI / 2);
    ctx.fillText(`${depth.toFixed(1)} ft`, 0, 0);
    ctx.restore();
}

function drawArrow(ctx, x, y, dx, dy) {
    const size = 8;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x - dy * size - dx * size, y - dx * size + dy * size);
    ctx.lineTo(x - dy * size + dx * size, y - dx * size - dy * size);
    ctx.closePath();
    ctx.fill();
}

function drawLegend(ctx, x, y) {
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(x, y, 200, 100);
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, 200, 100);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 14px Poppins';
    ctx.textAlign = 'left';
    ctx.fillText('LEGEND', x + 10, y + 20);

    const items = [
        { color: '#ffffff', text: 'Walls', width: 3 },
        { color: '#10b981', text: 'Doors', width: 4 },
        { color: '#3b82f6', text: 'Windows', width: 3 },
        { color: '#f59e0b', text: 'Dimensions', width: 1 }
    ];

    ctx.font = '12px Poppins';
    items.forEach((item, i) => {
        const itemY = y + 40 + i * 20;
        ctx.strokeStyle = item.color;
        ctx.lineWidth = item.width;
        ctx.beginPath();
        ctx.moveTo(x + 10, itemY);
        ctx.lineTo(x + 30, itemY);
        ctx.stroke();
        
        ctx.fillStyle = '#ffffff';
        ctx.fillText(item.text, x + 40, itemY + 4);
    });
}

function downloadBlueprint() {
    const canvas = document.getElementById('blueprintCanvas');
    if (!canvas) return;
    
    const link = document.createElement('a');
    const area = projectContext && projectContext.area ? projectContext.area : 'project';
    link.download = `BuildWise_Blueprint_${area}sqft.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
    
    // Show success message
    alert('✓ Blueprint downloaded successfully!');
}

// Expose to global scope
window.downloadBlueprint = downloadBlueprint;
