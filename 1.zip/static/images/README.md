# Images Folder

This folder is for storing static images used in the BuildWise application.

You can add:
- Logo files
- Background images
- Icons
- Sample house images
- Marketing materials

Currently using CSS-based graphics for the hero section house illustration.
