from flask import Flask, render_template, request, jsonify
import math
import requests
import datetime
import json
import os

app = Flask(__name__)

# Create data directory if it doesn't exist
if not os.path.exists('data'):
    os.makedirs('data')

# --- Indian Construction Standards & Rates (Approximate) ---
RATES = {
    'Basic': {'sqft_cost': (1600, 1900)},
    'Standard': {'sqft_cost': (2000, 2500)},
    'Premium': {'sqft_cost': (2600, 3500)}
}

# --- Logic Modules ---

class ProjectManager:
    @staticmethod
    def calculate_estimate(data):
        # Robust Data Parsing
        def safe_float(val, default=0):
            try:
                if not val: return default
                return float(val)
            except (ValueError, TypeError):
                return default

        area = safe_float(data.get('area'), 1000)
        floors = data.get('floors', 'G') # G, G+1, G+2
        quality = data.get('construction_type', 'Standard')
        
        # Floor Multiplier
        floor_count = 1
        if floors == 'G+1': floor_count = 2
        elif floors == 'G+2': floor_count = 3
        
        total_area = area * floor_count
        
        # Cost Calculation
        rate_min, rate_max = RATES.get(quality, RATES['Standard'])['sqft_cost']
        avg_rate = (rate_min + rate_max) / 2
        total_cost = total_area * avg_rate
        
        # Breakdown (Percentage based standard in India)
        breakdown = {
            'Foundation': round(total_cost * 0.15),
            'Structure': round(total_cost * 0.25),
            'Brickwork': round(total_cost * 0.12),
            'Plastering': round(total_cost * 0.10),
            'Electrical': round(total_cost * 0.08),
            'Plumbing': round(total_cost * 0.08),
            'Finishing': round(total_cost * 0.22) # Paint, Tiles, etc.
        }
        
        # Material Estimation (Simple heuristics)
        materials = {
            'Cement (Bags)': int(total_area * 0.45),
            'Steel (kg)': int(total_area * 3.5),
            'Sand (cu.ft)': int(total_area * 1.8),
            'Aggregate (cu.ft)': int(total_area * 1.35),
            'Bricks (nos)': int(total_area * 12),
            'Tiles (sq.ft)': int(total_area * 0.7), 
            'Paint (liters)': int(total_area * 0.15)
        }
        
        # Labor Estimation with Detailed Scheduling
        total_man_days = int(total_area * 0.6) # Approx days per sqft
        masons = max(2, int(total_area / 500))
        helpers = max(4, int(total_area / 250))
        carpenters = max(1, int(total_area / 1500))
        electricians = max(1, int(total_area / 1500))
        plumbers = max(1, int(total_area / 1500))
        
        # Schedule (Months)
        base_months = 6
        if floor_count == 2: base_months = 9
        elif floor_count == 3: base_months = 12
        
        # Detailed phase-wise worker schedule
        labor = {
            'summary': {
                'Masons': masons,
                'Helpers': helpers,
                'Carpenters': carpenters,
                'Electricians': electricians,
                'Plumbers': plumbers,
                'Supervisors': 1,
                'TotalManDays': total_man_days
            },
            'phases': [
                {
                    'phase': 'Phase 1: Foundation & Plinth',
                    'duration_weeks': int(base_months * 4 * 0.2),
                    'duration_days': int(base_months * 30 * 0.2),
                    'workers': [
                        {'role': 'Site Supervisor', 'count': 1, 'daily_rate': 1500, 'total_days': int(base_months * 30 * 0.2)},
                        {'role': 'Masons', 'count': masons, 'daily_rate': 800, 'total_days': int(base_months * 30 * 0.2)},
                        {'role': 'Helpers', 'count': helpers, 'daily_rate': 500, 'total_days': int(base_months * 30 * 0.2)},
                        {'role': 'Excavator Operator', 'count': 1, 'daily_rate': 1200, 'total_days': 5},
                        {'role': 'Bar Benders', 'count': 2, 'daily_rate': 700, 'total_days': int(base_months * 30 * 0.15)}
                    ],
                    'activities': ['Site clearing', 'Excavation', 'Foundation laying', 'Plinth beam work', 'Backfilling']
                },
                {
                    'phase': 'Phase 2: Superstructure',
                    'duration_weeks': int(base_months * 4 * 0.4),
                    'duration_days': int(base_months * 30 * 0.4),
                    'workers': [
                        {'role': 'Site Supervisor', 'count': 1, 'daily_rate': 1500, 'total_days': int(base_months * 30 * 0.4)},
                        {'role': 'Masons', 'count': masons + 1, 'daily_rate': 800, 'total_days': int(base_months * 30 * 0.4)},
                        {'role': 'Helpers', 'count': helpers + 2, 'daily_rate': 500, 'total_days': int(base_months * 30 * 0.4)},
                        {'role': 'Bar Benders', 'count': 2, 'daily_rate': 700, 'total_days': int(base_months * 30 * 0.3)},
                        {'role': 'Carpenters', 'count': carpenters + 1, 'daily_rate': 750, 'total_days': int(base_months * 30 * 0.35)},
                        {'role': 'Welders', 'count': 1, 'daily_rate': 900, 'total_days': 15}
                    ],
                    'activities': ['Column casting', 'Beam work', 'Slab casting', 'Wall construction', 'Roof structure']
                },
                {
                    'phase': 'Phase 3: MEP Works',
                    'duration_weeks': int(base_months * 4 * 0.2),
                    'duration_days': int(base_months * 30 * 0.2),
                    'workers': [
                        {'role': 'Site Supervisor', 'count': 1, 'daily_rate': 1500, 'total_days': int(base_months * 30 * 0.2)},
                        {'role': 'Electricians', 'count': electricians + 1, 'daily_rate': 850, 'total_days': int(base_months * 30 * 0.2)},
                        {'role': 'Plumbers', 'count': plumbers + 1, 'daily_rate': 800, 'total_days': int(base_months * 30 * 0.2)},
                        {'role': 'Helpers', 'count': 2, 'daily_rate': 500, 'total_days': int(base_months * 30 * 0.2)},
                        {'role': 'HVAC Technician', 'count': 1, 'daily_rate': 1000, 'total_days': 10}
                    ],
                    'activities': ['Electrical wiring', 'Plumbing installation', 'Drainage system', 'Water tank setup', 'AC provisions']
                },
                {
                    'phase': 'Phase 4: Finishing Works',
                    'duration_weeks': int(base_months * 4 * 0.2),
                    'duration_days': int(base_months * 30 * 0.2),
                    'workers': [
                        {'role': 'Site Supervisor', 'count': 1, 'daily_rate': 1500, 'total_days': int(base_months * 30 * 0.2)},
                        {'role': 'Painters', 'count': 3, 'daily_rate': 650, 'total_days': int(base_months * 30 * 0.15)},
                        {'role': 'Tile Masons', 'count': 2, 'daily_rate': 850, 'total_days': int(base_months * 30 * 0.18)},
                        {'role': 'Carpenters', 'count': carpenters + 1, 'daily_rate': 750, 'total_days': int(base_months * 30 * 0.18)},
                        {'role': 'Helpers', 'count': helpers, 'daily_rate': 500, 'total_days': int(base_months * 30 * 0.2)},
                        {'role': 'Marble/Granite Workers', 'count': 2, 'daily_rate': 900, 'total_days': 12},
                        {'role': 'Grill/Window Fitters', 'count': 2, 'daily_rate': 800, 'total_days': 8}
                    ],
                    'activities': ['Plastering', 'Flooring', 'Tiling', 'Painting', 'Door/window fitting', 'Kitchen setup', 'Final touches']
                }
            ]
        }
        
        schedule = {
            'Months': base_months,
            'Phases': [
                {'name': 'Foundation & Plinth', 'duration_weeks': int(base_months * 4 * 0.2), 'percentage': 20},
                {'name': 'Superstructure (Walls/Roof)', 'duration_weeks': int(base_months * 4 * 0.4), 'percentage': 40},
                {'name': 'MEP (Mechanical, Electrical, Plumbing)', 'duration_weeks': int(base_months * 4 * 0.2), 'percentage': 20},
                {'name': 'Finishing', 'duration_weeks': int(base_months * 4 * 0.2), 'percentage': 20}
            ]
        }
        
        # Risk Analysis
        user_budget = safe_float(data.get('budget'), 0)
        user_timeline = safe_float(data.get('timeline'), base_months)
        
        risks = []
        risk_level = "Low"
        
        if user_budget > 0 and user_budget < total_cost * 0.9:
            risks.append(f"Budget Deficit: Your budget of ₹{user_budget:,} is lower than estimated ₹{total_cost:,.0f}.")
            risk_level = "High"
        elif user_budget > 0 and user_budget < total_cost:
            risks.append("Budget Tight: Your budget is slightly below the estimate.")
            if risk_level != "High": risk_level = "Medium"
            
        if user_timeline < base_months * 0.8:
            risks.append(f"Timeline Crunch: {user_timeline} months is very aggressive. Recommended: {base_months} months.")
            risk_level = "High"
            
        return {
            'total_cost': total_cost,
            'per_floor_cost': total_cost / floor_count,
            'breakdown': breakdown,
            'materials': materials,
            'labor': labor,
            'schedule': schedule,
            'risk': {'level': risk_level, 'warnings': risks, 'explanation': "Based on current market rates and standard construction velocity."}
        }

# --- Routes ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/calculate', methods=['POST'])
def calculate():
    data = request.json
    
    # Save user registration data
    try:
        user_data = {
            'timestamp': datetime.datetime.now().isoformat(),
            'name': data.get('name', 'Anonymous'),
            'phone': data.get('phone', ''),
            'email': data.get('email', ''),
            'city': data.get('city', ''),
            'area': data.get('area', ''),
            'floors': data.get('floors', ''),
            'construction_type': data.get('construction_type', ''),
            'budget': data.get('budget', ''),
            'timeline': data.get('timeline', ''),
            'start_time': data.get('start_time', ''),
            'requirements': data.get('requirements', ''),
            'vastu': data.get('vastu', False)
        }
        
        # Save to JSON file
        registrations_file = 'data/registrations.json'
        registrations = []
        
        if os.path.exists(registrations_file):
            with open(registrations_file, 'r') as f:
                try:
                    registrations = json.load(f)
                except:
                    registrations = []
        
        registrations.append(user_data)
        
        with open(registrations_file, 'w') as f:
            json.dump(registrations, f, indent=2)
        
        print(f"✓ New registration saved: {user_data['name']} - {user_data['phone']}")
    except Exception as e:
        print(f"Error saving registration: {e}")
    
    # Calculate estimate
    result = ProjectManager.calculate_estimate(data)
    return jsonify(result)

@app.route('/api/chat', methods=['POST'])
def chat():
    """
    Dynamic AI chat using Ollama API with comprehensive fallback
    """
    data = request.json
    user_message = data.get('message', '')
    context = data.get('context', {})
    
    # Build context for AI
    context_info = ""
    if context.get('area'):
        floors = context.get('floors', 'G')
        multiplier = 1 if floors == 'G' else (2 if floors == 'G+1' else 3)
        total_area = float(context.get('area', 0)) * multiplier
        context_info = f"\n\nUser's Project: {context.get('area')} sqft/floor, {floors} floors, Total: {total_area} sqft, Type: {context.get('construction_type', 'N/A')}, Budget: ₹{context.get('budget', 'N/A')}"
    
    # Try Ollama API first
    try:
        system_prompt = f"""You are an expert Indian Construction Engineer with 20+ years of experience in residential construction.

Your expertise: Cost estimation, materials, timelines, Vastu, quality standards, labor, permits, electrical/plumbing, finishing, smart homes.

Guidelines:
- Use Indian English, costs in ₹ (Rupees)
- Be specific with numbers and practical advice
- Format with bullet points for lists
- Be friendly but professional
- Keep responses under 300 words

{context_info}

User: {user_message}

Response:"""

        ollama_response = requests.post(
            'http://localhost:11434/api/generate',
            json={
                "model": "llama2",
                "prompt": system_prompt,
                "stream": False
            },
            timeout=8
        )
        
        if ollama_response.status_code == 200:
            ai_response = ollama_response.json().get('response', '').strip()
            if ai_response and len(ai_response) > 20:
                return jsonify({'response': ai_response})
    
    except:
        pass  # Fall through to fallback
    
    # Comprehensive fallback
    response = get_smart_response(user_message.lower(), context)
    return jsonify({'response': response})


def get_smart_response(msg, context):
    """Smart fallback responses"""
    
    # Extract context
    area = float(context.get('area', 1200))
    floors = context.get('floors', 'G')
    mult = 1 if floors == 'G' else (2 if floors == 'G+1' else 3)
    total = area * mult
    
    # Customization
    if any(w in msg for w in ['customize', 'change', 'modify']):
        return "✓ BuildWise Customization:\n\n• Blueprint: Modify room layouts\n• 3D View: Change colors, roof types\n• Quality: Switch Basic/Standard/Premium\n• Floors: Add or remove\n\nWhat would you like to customize?"
    
    # Costs
    if any(w in msg for w in ['cost', 'price', 'budget', 'save', 'reduce']):
        return f"💰 Cost Tips:\n\n• Fly-ash bricks: Save ₹50-80/sqft\n• Bulk cement: 5-10% discount\n• Standard vs Premium: Save ₹800/sqft\n\nYour {total:.0f} sqft project:\n• Basic: ₹{total*1750:,.0f}\n• Standard: ₹{total*2200:,.0f}\n• Premium: ₹{total*3000:,.0f}"
    
    # Materials
    if any(w in msg for w in ['material', 'cement', 'steel', 'brick']):
        return f"📦 Materials for {total:.0f} sqft:\n\n• Cement: {int(total*0.45)} bags\n• Steel: {int(total*3.5)} kg\n• Bricks: {int(total*12):,}\n• Sand: {int(total*1.8)} cu.ft\n• Aggregate: {int(total*1.35)} cu.ft\n\n💡 Order 5-10% extra"
    
    # Timeline
    if any(w in msg for w in ['time', 'duration', 'long', 'month']):
        months = 6 if floors == 'G' else (9 if floors == 'G+1' else 12)
        return f"⏱️ Timeline for {floors}:\n\n• Foundation: {months*4*0.2:.0f} weeks\n• Structure: {months*4*0.4:.0f} weeks\n• MEP: {months*4*0.2:.0f} weeks\n• Finishing: {months*4*0.2:.0f} weeks\n\nTotal: ~{months} months\n\n⚠️ Don't rush concrete curing (21 days)"
    
    # Vastu
    if any(w in msg for w in ['vastu', 'direction']):
        return "🕉️ Vastu Guidelines:\n\n✓ Entrance: East/North\n✓ Kitchen: South-East\n✓ Master Bedroom: South-West\n✓ Living: North-East\n✓ Bathroom: North-West\n\nOur blueprints are Vastu-compliant!"
    
    # Labor
    if any(w in msg for w in ['labor', 'worker', 'mason']):
        return f"👷 Labor for {total:.0f} sqft:\n\n• Masons: {max(2, int(total/500))}\n• Helpers: {max(4, int(total/250))}\n• Carpenters: {max(1, int(total/1500))}\n• Electricians: {max(1, int(total/1500))}\n• Plumbers: {max(1, int(total/1500))}\n• Supervisor: 1\n\nTotal man-days: ~{int(total*0.6)}"
    
    # Flooring
    if any(w in msg for w in ['floor', 'tile', 'marble']):
        return "🏠 Flooring Options:\n\n• Marble: ₹200-500/sqft (premium)\n• Vitrified: ₹80-150/sqft (best value)\n• Granite: ₹150-300/sqft (durable)\n• Ceramic: ₹40-80/sqft (budget)\n\n💡 Recommend: Vitrified tiles"
    
    # Painting
    if any(w in msg for w in ['paint', 'color']):
        return f"🎨 Painting for {total:.0f} sqft:\n\n• Paint needed: {int(total*0.15)} liters\n• Economy: ₹15-25/sqft\n• Premium: ₹30-50/sqft\n• Luxury: ₹60-100/sqft\n\n💡 Use primer, 2 coats minimum"
    
    # Electrical
    if any(w in msg for w in ['electrical', 'wiring', 'switch']):
        return "⚡ Electrical Work:\n\n• Cost: 8% of budget\n• Duration: 2-3 weeks\n\n✓ Main DB & MCBs\n✓ Copper wiring\n✓ Switches & sockets\n✓ Proper earthing\n✓ ELCB/RCCB safety\n\n💡 Plan extra points!"
    
    # Plumbing
    if any(w in msg for w in ['plumb', 'pipe', 'water']):
        return "🚰 Plumbing Work:\n\n• Cost: 8% of budget\n• Duration: 2-3 weeks\n\n✓ CPVC/PPR pipes\n✓ PVC drainage\n✓ Quality fittings\n✓ Pressure testing\n\n💡 Keep layout simple"
    
    # Permits
    if any(w in msg for w in ['permit', 'approval', 'legal']):
        return "📋 Required Permits:\n\n1. Building Plan Approval\n2. Commencement Certificate\n3. Structural Certificate\n4. Occupancy Certificate\n5. Utility Connections\n\n⏱️ 2-4 months\n💰 ₹50K-2L\n\n⚠️ Get approvals first!"
    
    # Contractor
    if any(w in msg for w in ['contractor', 'builder', 'hire']):
        return "👷 Choosing Contractor:\n\n✓ Check past projects\n✓ Verify licenses\n✓ Get 3-4 quotes\n✓ Call references\n✓ Written contract\n\n⚠️ Red flags:\n• Full payment upfront\n• No contract\n• Very low quotes\n\n💡 Max 10% advance"
    
    # Greeting
    if any(w in msg for w in ['hi', 'hello', 'hey', 'namaste']):
        return "Namaste! 🙏\n\nI'm your AI Construction Engineer. I can help with:\n\n💰 Costs & budgeting\n📦 Materials\n⏱️ Timeline\n🕉️ Vastu\n🏗️ Construction details\n\nWhat would you like to know?"
    
    # Thanks
    if any(w in msg for w in ['thank', 'thanks', 'good', 'great']):
        return "You're welcome! 😊\n\nFeel free to ask anything about:\n• Construction costs\n• Materials\n• Timeline\n• Vastu\n• Quality standards\n\nI'm here 24/7! 🏠"
    
    # Default
    return f"I can help with:\n\n💰 Costs & budgeting\n📦 Materials (cement, steel, bricks)\n⏱️ Timeline planning\n🕉️ Vastu guidelines\n🏗️ Construction details\n👷 Labor requirements\n🎨 Finishing (paint, tiles)\n⚡ Electrical & plumbing\n\nPlease ask specifically:\n• 'How much cement?'\n• 'Best flooring option?'\n• 'Timeline for G+1?'\n\nWhat would you like to know?"


if __name__ == '__main__':
    print("\n" + "="*60)
    print("🏠 BuildWise - AI Construction Planner")
    print("="*60)
    print("\n✓ Server starting...")
    print("✓ Ollama integration enabled (fallback available)")
    print("✓ Open: http://localhost:5000")
    print("✓ Press CTRL+C to stop")
    print("\n" + "="*60 + "\n")
    app.run(debug=True, port=5000)
