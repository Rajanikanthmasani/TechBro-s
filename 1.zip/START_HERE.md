# 🚀 Quick Start Guide - BuildWise

## Step 1: Install Dependencies

Open your terminal/command prompt in this folder and run:

```bash
pip install -r requirements.txt
```

## Step 2: Start the Application

```bash
python app.py
```

You should see output like:
```
 * Running on http://127.0.0.1:5000
 * Debug mode: on
```

## Step 3: Open in Browser

Open your web browser and navigate to:
```
http://localhost:5000
```

## Step 4: Use the Application

1. **Fill the Form**: Scroll down on the home page and enter your project details
   - Built-up Area (e.g., 1200 sq ft)
   - Number of Floors (G, G+1, or G+2)
   - Construction Type (Basic/Standard/Premium)
   - Your Budget and Timeline
   - City

2. **Generate Plan**: Click "Generate Comprehensive Plan" button

3. **Explore Features**:
   - **Dashboard**: View cost breakdown, materials, labor requirements
   - **Blueprint**: See 2D floor plan (download as PNG)
   - **3D Model**: Interactive 3D visualization (rotate with mouse, change colors)
   - **Schedule**: Phase-wise construction timeline
   - **Chat**: Ask the AI engineer questions (bottom-right corner)

## 🎯 Quick Test

To verify everything works, run:
```bash
python test_app.py
```

This will test the calculation engine and show sample output.

## ⚠️ Troubleshooting

**Problem**: "Module not found" error
**Solution**: Make sure you installed dependencies: `pip install -r requirements.txt`

**Problem**: Port 5000 already in use
**Solution**: The app will automatically try another port, or you can stop other services using port 5000

**Problem**: 3D model not showing
**Solution**: Make sure you have internet connection (Three.js loads from CDN)

**Problem**: Chat not responding
**Solution**: The fallback AI is built-in and always works. For advanced AI, install Ollama separately.

## 📱 Features Overview

✅ Real-time cost estimation based on Indian rates
✅ Material quantity calculations (cement, steel, bricks, etc.)
✅ Labor planning with role-wise requirements
✅ Risk analysis for budget and timeline
✅ Vastu-compliant floor plans
✅ Interactive 3D house model
✅ AI chat assistant
✅ Downloadable blueprints
✅ Phase-wise construction schedule

## 🎨 Customization Tips

- **Change Wall Color**: In 3D Model view, use the color picker
- **Change Roof Type**: Click "Flat Roof" or "Sloped Roof" buttons
- **Download Blueprint**: Click "Download PNG" in Blueprint view
- **Ask Questions**: Use the chat widget for construction advice

## 📞 Need Help?

Check the README.md file for detailed documentation.

---
**Enjoy building your dream home with BuildWise! 🏠**
