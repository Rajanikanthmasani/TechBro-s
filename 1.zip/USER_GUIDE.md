# 📖 BuildWise - Complete User Guide

## Table of Contents
1. [Getting Started](#getting-started)
2. [Home Page](#home-page)
3. [Project Input](#project-input)
4. [Dashboard](#dashboard)
5. [Blueprint View](#blueprint-view)
6. [3D Model View](#3d-model-view)
7. [Schedule View](#schedule-view)
8. [AI Chat Assistant](#ai-chat-assistant)
9. [Tips & Best Practices](#tips--best-practices)

---

## Getting Started

### First Time Setup
1. Install Python dependencies: `pip install -r requirements.txt`
2. Start the server: `python app.py`
3. Open browser: `http://localhost:5000`

### Navigation
Use the sidebar on the left to switch between different views:
- **Home**: Landing page and project input
- **Dashboard**: Cost breakdown and analysis
- **Blueprint**: 2D floor plan
- **3D Model**: Interactive 3D visualization
- **Schedule**: Construction timeline

---

## Home Page

### Hero Section
The home page welcomes you with:
- **Headline**: "Build Your Dream Home with Confidence"
- **Trust Badges**: 
  - 🛡️ Escrow Safety
  - ✅ 430+ Quality Checks
  - 🚫 No Cost Overruns
- **CTA Button**: "Start Your Estimation" (scrolls to form)
- **Visual**: CSS-animated house graphic

### Features Section
Three key features are highlighted:
1. **Transparent Pricing**: Detailed Bill of Quantities
2. **On-Time Delivery**: Penalty clauses for delays
3. **Live Tracking**: Monitor progress from your phone

---

## Project Input

### Form Fields

#### 1. Built-up Area (Required)
- Enter the total construction area in square feet
- Example: 1200, 1500, 2000
- This is the per-floor area

#### 2. Floors (Required)
- **G**: Ground floor only (single story)
- **G+1**: Ground + 1st floor (2 stories)
- **G+2**: Ground + 2 floors (3 stories)

#### 3. Construction Type (Required)
Choose quality level:
- **Basic**: ₹1600/sqft - Economy materials, basic finishes
- **Standard**: ₹2200/sqft - Good quality, standard finishes (Recommended)
- **Premium**: ₹3000/sqft - High-end materials, luxury finishes

#### 4. Budget (Optional)
- Enter your available budget in Rupees
- Used for risk analysis
- Example: 5000000 (50 lakhs)

#### 5. Timeline (Optional)
- Desired completion time in months
- Used for feasibility check
- Example: 8, 10, 12

#### 6. Location (Required)
Select your city:
- Hyderabad
- Bangalore
- Mumbai
- Delhi
- Chennai

#### 7. Vastu Compliant Design (Optional)
- Check this box for Vastu-compliant floor plans
- Affects room placement in blueprint

### Submit
Click **"Generate Comprehensive Plan"** to:
- Calculate costs
- Generate materials list
- Create 3D model
- Draw blueprint
- Analyze risks

---

## Dashboard

### Key Performance Indicators (KPIs)

#### Total Estimate Card
- Shows total construction cost
- Formatted in Indian Rupees (₹)
- Based on area × floors × rate

#### Risk Analysis Card
- **Low** (Green): Budget and timeline are comfortable
- **Medium** (Orange): Slight concerns with budget/timeline
- **High** (Red): Significant budget deficit or timeline crunch
- Hover to see detailed warnings

#### Estimated Timeline Card
- Shows recommended construction duration
- In months
- Based on floor count and complexity

### Cost Breakdown Chart
- Interactive doughnut chart
- 7 major categories:
  1. Foundation (15%)
  2. Structure (25%)
  3. Brickwork (12%)
  4. Plastering (10%)
  5. Electrical (8%)
  6. Plumbing (8%)
  7. Finishing (22%)
- Hover over segments for exact amounts

### Material Requirements Table
Detailed quantities for:
- **Cement**: In bags (50kg each)
- **Steel**: In kilograms
- **Sand**: In cubic feet
- **Aggregate**: In cubic feet
- **Bricks**: Number of bricks
- **Tiles**: In square feet
- **Paint**: In liters

### Labor Planning Grid
Shows required workforce:
- **Masons**: Skilled workers for masonry
- **Helpers**: Unskilled labor
- **Carpenters**: For formwork and woodwork
- **Electricians**: For electrical installations
- **Plumbers**: For plumbing work
- **Supervisors**: Site management
- **Total Man-Days**: Overall labor requirement

---

## Blueprint View

### 2D Floor Plan
- **Dark Theme**: Professional blueprint appearance
- **Vastu Layout**: Rooms positioned per Vastu principles
  - **North-East**: Living Hall (most auspicious)
  - **South-East**: Kitchen (fire element)
  - **South-West**: Master Bedroom (stability)
  - **North-West**: Guest Room/Bathroom
- **Dimensions**: Shows width and total area
- **Doors**: Main entrance marked

### Controls
- **Download PNG**: Save blueprint as image file
- Use for:
  - Sharing with contractors
  - Printing
  - Documentation

### Interpretation
- White lines: Walls
- Labels: Room names with Vastu directions
- Gray text: Measurements

---

## 3D Model View

### Interactive Controls
- **Rotate**: Click and drag to rotate view
- **Zoom**: Scroll wheel to zoom in/out
- **Pan**: Right-click and drag to pan

### Customization Options

#### Wall Color Picker
- Click the color input
- Choose any color
- Model updates in real-time

#### Roof Type Buttons
- **Flat Roof**: Modern, contemporary style
- **Sloped Roof**: Traditional, pyramid-style

### Model Features
- **Multi-Floor**: Shows all floors based on input
- **Windows**: Blue glass windows on each floor
- **Balconies**: Added to upper floors (G+1, G+2)
- **Lighting**: Realistic shadows and lighting
- **Ground**: Green grass plane for context

### Tips
- Rotate to see all sides
- Zoom in to see details
- Try different colors to visualize finishes

---

## Schedule View

### Construction Phases

#### Phase 1: Foundation & Plinth (20% of timeline)
- Excavation
- Foundation laying
- Plinth beam construction
- Damp-proof course

#### Phase 2: Superstructure (40% of timeline)
- Column and beam construction
- Slab casting
- Wall construction
- Roof structure

#### Phase 3: MEP - Mechanical, Electrical, Plumbing (20% of timeline)
- Electrical wiring
- Plumbing installation
- HVAC preparation
- Conduit laying

#### Phase 4: Finishing (20% of timeline)
- Plastering
- Tile work
- Painting
- Fixtures installation
- Final touches

### Timeline Display
- Each phase shows duration in weeks
- Hover for more details
- Total adds up to estimated months

---

## AI Chat Assistant

### Location
- Fixed at bottom-right corner
- Click header to collapse/expand

### Features
- **Context-Aware**: Knows your project details
- **Indian Expertise**: Understands local construction practices
- **Professional Tone**: Addresses as "Sir/Madam"

### Sample Questions

#### Cost-Related
- "How can I reduce the cost?"
- "Is this budget enough for my project?"
- "What are the most expensive components?"
- "Can I save money on materials?"

#### Timeline-Related
- "How long will construction take?"
- "Can I speed up the timeline?"
- "What causes delays?"
- "Is my timeline realistic?"

#### Technical
- "What is the cement-sand ratio?"
- "How much steel is needed?"
- "What about foundation depth?"
- "Explain the curing process"

#### Vastu
- "Is this layout Vastu compliant?"
- "Where should the main door be?"
- "Kitchen placement as per Vastu?"

### Response Types
- **With Ollama**: Advanced AI responses (if installed)
- **Fallback**: Rule-based intelligent responses (always available)

### Tips
- Be specific in your questions
- Mention your concern clearly
- Ask follow-up questions
- Press Enter to send

---

## Tips & Best Practices

### Input Accuracy
✅ **Do**: Enter accurate measurements
✅ **Do**: Be realistic with budget
✅ **Do**: Consider local rates
❌ **Don't**: Underestimate area
❌ **Don't**: Set unrealistic timelines

### Budget Planning
- Add 10-15% buffer for contingencies
- Standard quality offers best value
- Premium increases cost by 35-40%
- Basic saves 25-30% but compromises quality

### Timeline Expectations
- **G Floor**: 5-6 months minimum
- **G+1**: 8-9 months minimum
- **G+2**: 11-12 months minimum
- Weather delays: Add 1-2 months
- Approval delays: Add 1 month

### Material Procurement
- Buy cement in bulk for discounts
- Order steel from authorized dealers
- Use fly-ash bricks to save costs
- Purchase tiles during sale seasons

### Quality Checks
- Verify cement grade (43 or 53)
- Check steel ISI marks
- Test sand for silt content
- Ensure proper curing (21 days)

### Using the 3D Model
- Show to family for visualization
- Share with architect for feedback
- Use for interior planning
- Export screenshots for reference

### Using the Blueprint
- Print for site reference
- Share with contractors for quotes
- Use for furniture planning
- Keep for documentation

### Risk Management
- If risk is "High", reconsider budget/timeline
- "Medium" risk is manageable with planning
- "Low" risk means good feasibility
- Always maintain contingency fund

---

## Keyboard Shortcuts

- **Enter** in chat: Send message
- **Scroll** in 3D view: Zoom
- **Click + Drag** in 3D: Rotate
- **Right-click + Drag** in 3D: Pan

---

## Troubleshooting

### Issue: Blank Dashboard
**Solution**: Generate estimate from Home page first

### Issue: 3D Model Not Loading
**Solution**: Check internet connection (Three.js loads from CDN)

### Issue: Chat Not Responding
**Solution**: Wait a few seconds, fallback system always works

### Issue: Blueprint Not Showing
**Solution**: Switch to another view and back to Blueprint

### Issue: Calculations Seem Wrong
**Solution**: Verify input values, especially area and floors

---

## Support

For issues or questions:
1. Check this user guide
2. Review README.md
3. Run test_app.py to verify installation
4. Check FEATURES_CHECKLIST.md for feature status

---

**Happy Building! 🏠✨**
